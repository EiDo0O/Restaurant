﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Restraurant_P_1.DB;

namespace Restraurant_P_1
{
    public partial class AddStuff : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        public AddStuff()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Added Successfully");
             db.Stuff1.Add(new Restraurant_P_1.DB.Stuff1
             {
                StuffName = StuffName.Text,
                StuffAddress = StuffAdd.Text,
                StuffPhone = int.Parse(StuffPhoneNum.Text),
                StuffEmail = StuffEmail.Text ,
                StuffSalary = int.Parse(StuffSalary.Text) ,
                StuffCategory = StuffCategory.Text
            }
                ); 
            db.SaveChanges();
            this.Close();
        }
    }
}
