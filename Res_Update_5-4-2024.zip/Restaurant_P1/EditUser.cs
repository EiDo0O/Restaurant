﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class EditUser : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        public EditUser()
        {
            InitializeComponent();
            UserGrid.DataSource = db.Users.ToList();

        }

        private void EditUser_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'restaurantDataSet1.Users' table. You can move, or remove it, as needed.
            this.usersTableAdapter.Fill(this.restaurantDataSet1.Users);

        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Users.Where(x => x.UserName.Contains(UserSearchField.Text)).ToList();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Users.Where(x => x.UserName.Contains(UserSearchField.Text)).ToList();

        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Users.ToList();

        }

        

        private void Home_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new MainForm());
        }
    private void UserGrid_SelectionChanged(object sender, EventArgs e)
            {
                int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
                var Select = db.Users.SingleOrDefault(x => x.Id == IdObj);

                UserName.Text = Select.UserName;
                UserPW.Text = Select.UserPassword;
                UserPhoneNum.Text = Select.UserPhone.ToString();
                UserEmail.Text = Select.UserEmail;

            }

        private void UserGrid_SelectionChanged_1(object sender, EventArgs e)
        {
            int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
            var Select = db.Users.SingleOrDefault(x => x.Id == IdObj);

            UserName.Text = Select.UserName;
            UserPW.Text = Select.UserPassword;
            UserPhoneNum.Text = Select.UserPhone.ToString();
            UserEmail.Text = Select.UserEmail;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
            var Select = db.Users.SingleOrDefault(x => x.Id == IdObj);

             Select.UserName = UserName.Text ;
             Select.UserPassword = UserPW.Text ;
             Select.UserPhone = int.Parse(UserPhoneNum.Text) ;
             Select.UserEmail = UserEmail.Text ;

            db.SaveChanges();
            MessageBox.Show("Saved Successfully");
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
            var Select = db.Users.SingleOrDefault(x => x.Id == IdObj);

            Select.UserName = UserName.Text;
            Select.UserPassword = UserPW.Text;
            Select.UserPhone = int.Parse(UserPhoneNum.Text);
            Select.UserEmail = UserEmail.Text;

            db.SaveChanges();
            MessageBox.Show("Saved Successfully");
        }
    }
    }
    

