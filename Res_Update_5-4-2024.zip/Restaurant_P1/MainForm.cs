﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void تسجيلالدخولToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Registeration reg = new Registeration();
            reg.Show();
        }

        private void إغلاقToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void إضافةمستخدمجديدToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new New_register());
        }

        private void عرضجميعالمستخدمينToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm2);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm2()
        {
            Application.Run(new AllUsers());
        }

        private void تعديلالمستخدمينToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm3);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm3()
        {
            Application.Run(new EditUser());
        }

        private void تعديلمستخدمToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm4);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm4()
        {
            Application.Run(new EditUser());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm5);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm5()
        {
            Application.Run(new StuffInfo());
        }

        private void Registeration_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm6);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm6()
        {
            Application.Run(new MenuShow());
        }

        private void كتابةتقريرجديدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm7);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm7()
        {
            Application.Run(new Reports());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm8);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm8()
        {
            Application.Run(new Case());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SalesForm sale = new SalesForm();
            sale.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DeliveryForm D = new DeliveryForm();
            D.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm9);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm9()
        {
            Application.Run(new RequirmentsForm());
        }

        private void عرضجميعالعملاءToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm10);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm10()
        {
            Application.Run(new CustomersForm());
        }

        private void إضافةعميلجديدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddCustomer Ac = new AddCustomer();
            Ac.Show();
        }

        private void تعديلعملاءToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddCustomer Ac = new AddCustomer();
            Ac.Show();
        }

        private void تعديلعاملينToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm11);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm11()
        {
            Application.Run(new StuffInfo());
        }

        private void تعديلطعامToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm12);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm12()
        {
            Application.Run(new MenuShow());
        }

        private void الفواتيرToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm13);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm13()
        {
            Application.Run(new Bill());
        }
    }
}
