﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class CustomersForm : Form
    {

        // public static CustomersForm b1;
     
        RestaurantEnteties db = new RestaurantEnteties();
        public CustomersForm()
        {
            InitializeComponent();
          //  b1 = this;
        }

        private void CustomersForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'restaurantDataSet16.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.restaurantDataSet16.Customers);

        }

        private void Home_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new MainForm());
        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Customers.ToList();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
            var Select = db.Customers.SingleOrDefault(x => x.Id == IdObj);
            db.Customers.Remove(Select);

            db.SaveChanges();
            MessageBox.Show("Removed Successfully");
            UserGrid.DataSource = db.Customers.ToList();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AddCustomer Ac = new AddCustomer();
            Ac.Show();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Customers.Where(x => x.CusPhone.ToString() == CusSearchField.Text).ToList();

        }

        private void UserGrid_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
                var Select = db.Customers.SingleOrDefault(x => x.Id == IdObj);

                CusNameBox.Text = Select.CusName;
                CusAddBox.Text = Select.CusAddress;
                CusPhoneBox.Text = Select.CusPhone.ToString();
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bill b = new Bill(CusNameBox.Text, CusPhoneBox.Text, CusAddBox.Text);
            b.Show();
            /*
            Bill.b1.tb1.Text = CusNameBox.Text;
            Bill.b1.tb2.Text = CusPhoneBox.Text;
            Bill.b1.tb3.Text = CusAddBox.Text;
            */
        }

       

        private void CusNameBox_TextChanged(object sender, EventArgs e)
        {
            /*
            var y = Application.OpenForms["Bill"] as Bill;
            y.BillName.Text = CusNameBox.Text;
            */
        }
    }
}
