﻿
namespace Restraurant_P_1
{
    partial class Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.CusNameBill = new System.Windows.Forms.TextBox();
            this.CusPhoneBill = new System.Windows.Forms.TextBox();
            this.CusAddBill = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.UserPhone = new System.Windows.Forms.Label();
            this.user_name = new System.Windows.Forms.Label();
            this.UserGrid = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodCategoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet17 = new Restraurant_P_1.RestaurantDataSet17();
            this.label1 = new System.Windows.Forms.Label();
            this.foodTableAdapter = new Restraurant_P_1.RestaurantDataSet17TableAdapters.FoodTableAdapter();
            this.label2 = new System.Windows.Forms.Label();
            this.OrderGrid = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodNameDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodQtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.priceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet18 = new Restraurant_P_1.RestaurantDataSet18();
            this.label3 = new System.Windows.Forms.Label();
            this.FoodNameBill = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.FoodQuantityBill = new System.Windows.Forms.ComboBox();
            this.FoodSearchField = new System.Windows.Forms.TextBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.AddButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.Total = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Sale = new System.Windows.Forms.TextBox();
            this.Print = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.CashName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.DateTimeBox = new System.Windows.Forms.TextBox();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.orderListTableAdapter = new Restraurant_P_1.RestaurantDataSet18TableAdapters.OrderListTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.OrderList2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderList2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet25 = new Restraurant_P_1.RestaurantDataSet25();
            this.restaurantDataSet21 = new Restraurant_P_1.RestaurantDataSet21();
            this.orderList2TableAdapter = new Restraurant_P_1.RestaurantDataSet25TableAdapters.OrderList2TableAdapter();
            this.Home = new System.Windows.Forms.Button();
            this.Indoor = new System.Windows.Forms.RadioButton();
            this.TakeAway = new System.Windows.Forms.RadioButton();
            this.Delivery = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderList2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet21)).BeginInit();
            this.SuspendLayout();
            // 
            // CusNameBill
            // 
            this.CusNameBill.Location = new System.Drawing.Point(548, 76);
            this.CusNameBill.Multiline = true;
            this.CusNameBill.Name = "CusNameBill";
            this.CusNameBill.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CusNameBill.Size = new System.Drawing.Size(153, 18);
            this.CusNameBill.TabIndex = 120;
            // 
            // CusPhoneBill
            // 
            this.CusPhoneBill.Location = new System.Drawing.Point(548, 113);
            this.CusPhoneBill.Multiline = true;
            this.CusPhoneBill.Name = "CusPhoneBill";
            this.CusPhoneBill.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CusPhoneBill.Size = new System.Drawing.Size(153, 18);
            this.CusPhoneBill.TabIndex = 119;
            // 
            // CusAddBill
            // 
            this.CusAddBill.Location = new System.Drawing.Point(547, 151);
            this.CusAddBill.Multiline = true;
            this.CusAddBill.Name = "CusAddBill";
            this.CusAddBill.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CusAddBill.Size = new System.Drawing.Size(153, 39);
            this.CusAddBill.TabIndex = 118;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Maroon;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(730, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 14);
            this.label4.TabIndex = 124;
            this.label4.Text = "العنوان";
            // 
            // UserPhone
            // 
            this.UserPhone.AutoSize = true;
            this.UserPhone.BackColor = System.Drawing.Color.Maroon;
            this.UserPhone.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserPhone.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.UserPhone.Location = new System.Drawing.Point(717, 116);
            this.UserPhone.Name = "UserPhone";
            this.UserPhone.Size = new System.Drawing.Size(73, 14);
            this.UserPhone.TabIndex = 123;
            this.UserPhone.Text = "رقم التليفون";
            this.UserPhone.Click += new System.EventHandler(this.UserPhone_Click);
            // 
            // user_name
            // 
            this.user_name.AutoSize = true;
            this.user_name.BackColor = System.Drawing.Color.Maroon;
            this.user_name.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.user_name.Location = new System.Drawing.Point(723, 80);
            this.user_name.Name = "user_name";
            this.user_name.Size = new System.Drawing.Size(65, 14);
            this.user_name.TabIndex = 121;
            this.user_name.Text = "اسم العميل";
            this.user_name.Click += new System.EventHandler(this.user_name_Click);
            // 
            // UserGrid
            // 
            this.UserGrid.AutoGenerateColumns = false;
            this.UserGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UserGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.foodNameDataGridViewTextBoxColumn,
            this.foodQuantityDataGridViewTextBoxColumn,
            this.foodCategoryDataGridViewTextBoxColumn,
            this.foodPriceDataGridViewTextBoxColumn,
            this.categoryIdDataGridViewTextBoxColumn});
            this.UserGrid.DataSource = this.foodBindingSource;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.UserGrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.UserGrid.Location = new System.Drawing.Point(59, 80);
            this.UserGrid.Name = "UserGrid";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.UserGrid.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.UserGrid.Size = new System.Drawing.Size(412, 167);
            this.UserGrid.TabIndex = 125;
            this.UserGrid.SelectionChanged += new System.EventHandler(this.UserGrid_SelectionChanged);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 40;
            // 
            // foodNameDataGridViewTextBoxColumn
            // 
            this.foodNameDataGridViewTextBoxColumn.DataPropertyName = "FoodName";
            this.foodNameDataGridViewTextBoxColumn.HeaderText = "FoodName";
            this.foodNameDataGridViewTextBoxColumn.Name = "foodNameDataGridViewTextBoxColumn";
            this.foodNameDataGridViewTextBoxColumn.Width = 90;
            // 
            // foodQuantityDataGridViewTextBoxColumn
            // 
            this.foodQuantityDataGridViewTextBoxColumn.DataPropertyName = "FoodQuantity";
            this.foodQuantityDataGridViewTextBoxColumn.HeaderText = "FoodQuantity";
            this.foodQuantityDataGridViewTextBoxColumn.Name = "foodQuantityDataGridViewTextBoxColumn";
            this.foodQuantityDataGridViewTextBoxColumn.Width = 80;
            // 
            // foodCategoryDataGridViewTextBoxColumn
            // 
            this.foodCategoryDataGridViewTextBoxColumn.DataPropertyName = "FoodCategory";
            this.foodCategoryDataGridViewTextBoxColumn.HeaderText = "FoodCategory";
            this.foodCategoryDataGridViewTextBoxColumn.Name = "foodCategoryDataGridViewTextBoxColumn";
            this.foodCategoryDataGridViewTextBoxColumn.Width = 90;
            // 
            // foodPriceDataGridViewTextBoxColumn
            // 
            this.foodPriceDataGridViewTextBoxColumn.DataPropertyName = "FoodPrice";
            this.foodPriceDataGridViewTextBoxColumn.HeaderText = "FoodPrice";
            this.foodPriceDataGridViewTextBoxColumn.Name = "foodPriceDataGridViewTextBoxColumn";
            this.foodPriceDataGridViewTextBoxColumn.Width = 70;
            // 
            // categoryIdDataGridViewTextBoxColumn
            // 
            this.categoryIdDataGridViewTextBoxColumn.DataPropertyName = "CategoryId";
            this.categoryIdDataGridViewTextBoxColumn.HeaderText = "CategoryId";
            this.categoryIdDataGridViewTextBoxColumn.Name = "categoryIdDataGridViewTextBoxColumn";
            this.categoryIdDataGridViewTextBoxColumn.Width = 90;
            // 
            // foodBindingSource
            // 
            this.foodBindingSource.DataMember = "Food";
            this.foodBindingSource.DataSource = this.restaurantDataSet17;
            // 
            // restaurantDataSet17
            // 
            this.restaurantDataSet17.DataSetName = "RestaurantDataSet17";
            this.restaurantDataSet17.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Maroon;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(354, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 27);
            this.label1.TabIndex = 126;
            this.label1.Text = "قائمة الطعام";
            // 
            // foodTableAdapter
            // 
            this.foodTableAdapter.ClearBeforeFill = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Maroon;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(354, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 27);
            this.label2.TabIndex = 128;
            this.label2.Text = "قائمة الطلب";
            // 
            // OrderGrid
            // 
            this.OrderGrid.AllowUserToAddRows = false;
            this.OrderGrid.AutoGenerateColumns = false;
            this.OrderGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OrderGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.foodNameDataGridViewTextBoxColumn1,
            this.foodQtyDataGridViewTextBoxColumn,
            this.priceDataGridViewTextBoxColumn});
            this.OrderGrid.DataSource = this.orderListBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OrderGrid.DefaultCellStyle = dataGridViewCellStyle3;
            this.OrderGrid.Location = new System.Drawing.Point(112, 299);
            this.OrderGrid.Name = "OrderGrid";
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.OrderGrid.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.OrderGrid.Size = new System.Drawing.Size(359, 98);
            this.OrderGrid.TabIndex = 127;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            this.idDataGridViewTextBoxColumn1.Width = 25;
            // 
            // foodNameDataGridViewTextBoxColumn1
            // 
            this.foodNameDataGridViewTextBoxColumn1.DataPropertyName = "FoodName";
            this.foodNameDataGridViewTextBoxColumn1.HeaderText = "FoodName";
            this.foodNameDataGridViewTextBoxColumn1.Name = "foodNameDataGridViewTextBoxColumn1";
            this.foodNameDataGridViewTextBoxColumn1.Width = 150;
            // 
            // foodQtyDataGridViewTextBoxColumn
            // 
            this.foodQtyDataGridViewTextBoxColumn.DataPropertyName = "FoodQty";
            this.foodQtyDataGridViewTextBoxColumn.HeaderText = "FoodQty";
            this.foodQtyDataGridViewTextBoxColumn.Name = "foodQtyDataGridViewTextBoxColumn";
            this.foodQtyDataGridViewTextBoxColumn.Width = 60;
            // 
            // priceDataGridViewTextBoxColumn
            // 
            this.priceDataGridViewTextBoxColumn.DataPropertyName = "Price";
            this.priceDataGridViewTextBoxColumn.HeaderText = "Price";
            this.priceDataGridViewTextBoxColumn.Name = "priceDataGridViewTextBoxColumn";
            this.priceDataGridViewTextBoxColumn.Width = 80;
            // 
            // orderListBindingSource
            // 
            this.orderListBindingSource.DataMember = "OrderList";
            this.orderListBindingSource.DataSource = this.restaurantDataSet18;
            // 
            // restaurantDataSet18
            // 
            this.restaurantDataSet18.DataSetName = "RestaurantDataSet18";
            this.restaurantDataSet18.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Maroon;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(730, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 14);
            this.label3.TabIndex = 130;
            this.label3.Text = "اسم الصنف";
            // 
            // FoodNameBill
            // 
            this.FoodNameBill.Location = new System.Drawing.Point(555, 267);
            this.FoodNameBill.Multiline = true;
            this.FoodNameBill.Name = "FoodNameBill";
            this.FoodNameBill.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.FoodNameBill.Size = new System.Drawing.Size(153, 18);
            this.FoodNameBill.TabIndex = 129;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Maroon;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(740, 317);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 14);
            this.label5.TabIndex = 131;
            this.label5.Text = "الكمية";
            // 
            // FoodQuantityBill
            // 
            this.FoodQuantityBill.DisplayMember = "Category";
            this.FoodQuantityBill.FormattingEnabled = true;
            this.FoodQuantityBill.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.FoodQuantityBill.Location = new System.Drawing.Point(656, 312);
            this.FoodQuantityBill.Name = "FoodQuantityBill";
            this.FoodQuantityBill.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.FoodQuantityBill.Size = new System.Drawing.Size(52, 21);
            this.FoodQuantityBill.TabIndex = 132;
            this.FoodQuantityBill.ValueMember = "Id";
            // 
            // FoodSearchField
            // 
            this.FoodSearchField.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FoodSearchField.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.FoodSearchField.Location = new System.Drawing.Point(91, 52);
            this.FoodSearchField.Multiline = true;
            this.FoodSearchField.Name = "FoodSearchField";
            this.FoodSearchField.Size = new System.Drawing.Size(134, 24);
            this.FoodSearchField.TabIndex = 133;
            this.FoodSearchField.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.Color.Maroon;
            this.SearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SearchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SearchButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SearchButton.Location = new System.Drawing.Point(230, 53);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(53, 24);
            this.SearchButton.TabIndex = 134;
            this.SearchButton.Text = "بحث";
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // AddButton
            // 
            this.AddButton.BackColor = System.Drawing.Color.Maroon;
            this.AddButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.AddButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.AddButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AddButton.Location = new System.Drawing.Point(570, 308);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(50, 31);
            this.AddButton.TabIndex = 135;
            this.AddButton.Text = "إضافة";
            this.AddButton.UseVisualStyleBackColor = false;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Maroon;
            this.label6.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(635, 392);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 14);
            this.label6.TabIndex = 136;
            this.label6.Text = "الاجمالي";
            // 
            // Total
            // 
            this.Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total.ForeColor = System.Drawing.Color.Red;
            this.Total.Location = new System.Drawing.Point(555, 378);
            this.Total.Multiline = true;
            this.Total.Name = "Total";
            this.Total.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Total.Size = new System.Drawing.Size(74, 37);
            this.Total.TabIndex = 137;
            this.Total.Text = "0.00";
            this.Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Maroon;
            this.label7.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(742, 392);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(39, 14);
            this.label7.TabIndex = 138;
            this.label7.Text = "الخصم";
            // 
            // Sale
            // 
            this.Sale.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sale.Location = new System.Drawing.Point(705, 386);
            this.Sale.Name = "Sale";
            this.Sale.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Sale.Size = new System.Drawing.Size(31, 24);
            this.Sale.TabIndex = 139;
            this.Sale.Text = "0%";
            this.Sale.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Sale.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Sale_KeyDown);
            // 
            // Print
            // 
            this.Print.BackColor = System.Drawing.Color.Maroon;
            this.Print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Print.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Print.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Print.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Print.Location = new System.Drawing.Point(6, 415);
            this.Print.Name = "Print";
            this.Print.Size = new System.Drawing.Size(91, 31);
            this.Print.TabIndex = 140;
            this.Print.Text = "طباعة فاتورة";
            this.Print.UseVisualStyleBackColor = false;
            this.Print.Click += new System.EventHandler(this.Print_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Maroon;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(717, 209);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 14);
            this.label8.TabIndex = 141;
            this.label8.Text = "حالة الاوردر";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Maroon;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(616, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(177, 45);
            this.label9.TabIndex = 143;
            this.label9.Text = "فاتـورة البيع";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Maroon;
            this.label10.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(510, 11);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 14);
            this.label10.TabIndex = 145;
            this.label10.Text = "اسم الكاشير";
            // 
            // CashName
            // 
            this.CashName.Location = new System.Drawing.Point(335, 7);
            this.CashName.Multiline = true;
            this.CashName.Name = "CashName";
            this.CashName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CashName.Size = new System.Drawing.Size(153, 18);
            this.CashName.TabIndex = 144;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Maroon;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(217, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(90, 14);
            this.label11.TabIndex = 147;
            this.label11.Text = "التاريخ / الوقت";
            // 
            // DateTimeBox
            // 
            this.DateTimeBox.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateTimeBox.Location = new System.Drawing.Point(50, 7);
            this.DateTimeBox.Multiline = true;
            this.DateTimeBox.Name = "DateTimeBox";
            this.DateTimeBox.Size = new System.Drawing.Size(145, 21);
            this.DateTimeBox.TabIndex = 146;
            // 
            // Timer
            // 
            this.Timer.Enabled = true;
            this.Timer.Interval = 1000;
            this.Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // orderListTableAdapter
            // 
            this.orderListTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.Location = new System.Drawing.Point(113, 300);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(42, 21);
            this.button1.TabIndex = 148;
            this.button1.Text = "حذف";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // OrderList2
            // 
            this.OrderList2.AllowUserToAddRows = false;
            this.OrderList2.AutoGenerateColumns = false;
            this.OrderList2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OrderList2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.OrderList2.DataSource = this.orderList2BindingSource;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OrderList2.DefaultCellStyle = dataGridViewCellStyle5;
            this.OrderList2.Location = new System.Drawing.Point(130, 451);
            this.OrderList2.Name = "OrderList2";
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.OrderList2.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.OrderList2.Size = new System.Drawing.Size(359, 98);
            this.OrderList2.TabIndex = 149;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Id";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 25;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "FoodName";
            this.dataGridViewTextBoxColumn2.HeaderText = "FoodName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FoodQty";
            this.dataGridViewTextBoxColumn3.HeaderText = "FoodQty";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 60;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Price";
            this.dataGridViewTextBoxColumn4.HeaderText = "Price";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 80;
            // 
            // orderList2BindingSource
            // 
            this.orderList2BindingSource.DataMember = "OrderList2";
            this.orderList2BindingSource.DataSource = this.restaurantDataSet25;
            // 
            // restaurantDataSet25
            // 
            this.restaurantDataSet25.DataSetName = "RestaurantDataSet25";
            this.restaurantDataSet25.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // restaurantDataSet21
            // 
            this.restaurantDataSet21.DataSetName = "RestaurantDataSet21";
            this.restaurantDataSet21.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // orderList2TableAdapter
            // 
            this.orderList2TableAdapter.ClearBeforeFill = true;
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.Color.Maroon;
            this.Home.BackgroundImage = global::Restraurant_P_1.Properties.Resources._75;
            this.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Home.Location = new System.Drawing.Point(4, 6);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(28, 25);
            this.Home.TabIndex = 150;
            this.Home.UseVisualStyleBackColor = false;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // Indoor
            // 
            this.Indoor.AutoSize = true;
            this.Indoor.Checked = true;
            this.Indoor.Location = new System.Drawing.Point(658, 208);
            this.Indoor.Name = "Indoor";
            this.Indoor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Indoor.Size = new System.Drawing.Size(46, 17);
            this.Indoor.TabIndex = 151;
            this.Indoor.TabStop = true;
            this.Indoor.Text = "صالة";
            this.Indoor.UseVisualStyleBackColor = true;
            this.Indoor.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // TakeAway
            // 
            this.TakeAway.AutoSize = true;
            this.TakeAway.Location = new System.Drawing.Point(580, 208);
            this.TakeAway.Name = "TakeAway";
            this.TakeAway.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TakeAway.Size = new System.Drawing.Size(68, 17);
            this.TakeAway.TabIndex = 152;
            this.TakeAway.Text = "تيك أواي";
            this.TakeAway.UseVisualStyleBackColor = true;
            this.TakeAway.CheckedChanged += new System.EventHandler(this.TakeAway_CheckedChanged);
            // 
            // Delivery
            // 
            this.Delivery.AutoSize = true;
            this.Delivery.Location = new System.Drawing.Point(514, 208);
            this.Delivery.Name = "Delivery";
            this.Delivery.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Delivery.Size = new System.Drawing.Size(57, 17);
            this.Delivery.TabIndex = 153;
            this.Delivery.Text = "دليفري";
            this.Delivery.UseVisualStyleBackColor = true;
            this.Delivery.CheckedChanged += new System.EventHandler(this.Delivery_CheckedChanged);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Maroon;
            this.button2.BackgroundImage = global::Restraurant_P_1.Properties.Resources._76;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(62, 54);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(24, 20);
            this.button2.TabIndex = 154;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._91;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Delivery);
            this.Controls.Add(this.TakeAway);
            this.Controls.Add(this.Indoor);
            this.Controls.Add(this.Home);
            this.Controls.Add(this.OrderList2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.DateTimeBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.CashName);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.Print);
            this.Controls.Add(this.Sale);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.FoodSearchField);
            this.Controls.Add(this.FoodQuantityBill);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.FoodNameBill);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.OrderGrid);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UserGrid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.UserPhone);
            this.Controls.Add(this.user_name);
            this.Controls.Add(this.CusNameBill);
            this.Controls.Add(this.CusPhoneBill);
            this.Controls.Add(this.CusAddBill);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(816, 489);
            this.MinimumSize = new System.Drawing.Size(816, 489);
            this.Name = "Bill";
            this.Text = "Bill";
            this.Load += new System.EventHandler(this.Bill_Load);
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderList2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet21)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox CusNameBill;
        private System.Windows.Forms.TextBox CusPhoneBill;
        private System.Windows.Forms.TextBox CusAddBill;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label UserPhone;
        private System.Windows.Forms.Label user_name;
        private System.Windows.Forms.DataGridView UserGrid;
        private System.Windows.Forms.Label label1;
        private RestaurantDataSet17 restaurantDataSet17;
        private System.Windows.Forms.BindingSource foodBindingSource;
        private RestaurantDataSet17TableAdapters.FoodTableAdapter foodTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodCategoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView OrderGrid;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox FoodNameBill;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox FoodQuantityBill;
        private System.Windows.Forms.TextBox FoodSearchField;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox Total;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.TextBox Sale;
        private System.Windows.Forms.Button Print;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.TextBox CashName;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox DateTimeBox;
        private System.Windows.Forms.Timer Timer;
        private RestaurantDataSet18 restaurantDataSet18;
        private System.Windows.Forms.BindingSource orderListBindingSource;
        private RestaurantDataSet18TableAdapters.OrderListTableAdapter orderListTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodNameDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodQtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn priceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView OrderList2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private RestaurantDataSet21 restaurantDataSet21;
        private RestaurantDataSet25 restaurantDataSet25;
        private System.Windows.Forms.BindingSource orderList2BindingSource;
        private RestaurantDataSet25TableAdapters.OrderList2TableAdapter orderList2TableAdapter;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.RadioButton Indoor;
        private System.Windows.Forms.RadioButton TakeAway;
        private System.Windows.Forms.RadioButton Delivery;
        private System.Windows.Forms.Button button2;
    }
}