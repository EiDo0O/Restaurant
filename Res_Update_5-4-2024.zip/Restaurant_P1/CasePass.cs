﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class CasePass : Form
    {
        private float bud = Budget.budget;

        public CasePass()
        {
            InitializeComponent();
        }

        private void PwButton_Click(object sender, EventArgs e)
        {
            
            if (PW.Text == "111")
            {
                MessageBox.Show("Your Budget = " + bud);
            } else
            {
                MessageBox.Show("Password is invalid !");

            }
        }
    }
}
