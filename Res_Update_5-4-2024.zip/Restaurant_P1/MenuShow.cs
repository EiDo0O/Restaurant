﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class MenuShow : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();

        public MenuShow()
        {
            InitializeComponent();
        }

        private void MenuShow_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'restaurantDataSet7.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this.restaurantDataSet7.Category);
            // TODO: This line of code loads data into the 'restaurantDataSet6.Food' table. You can move, or remove it, as needed.
            this.foodTableAdapter1.Fill(this.restaurantDataSet6.Food);
            // TODO: This line of code loads data into the 'restaurantDataSet5.Food' table. You can move, or remove it, as needed.
            this.foodTableAdapter.Fill(this.restaurantDataSet5.Food);

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void UserGrid_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
                var Select = db.Foods.SingleOrDefault(x => x.Id == IdObj);

                FoodName.Text = Select.FoodName;
                FoodQuantity.Text = Select.FoodQuantity.ToString();
                FoodPrice.Text = Select.FoodPrice.ToString();
                CategoryCombo.SelectedValue = Select.CategoryId;
            }
            catch { }

        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Foods.Where(x => x.FoodName.Contains(FoodSearchField.Text)).ToList();

        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Foods.ToList();

        }

        private void Home_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new MainForm());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AddFood AddFood = new AddFood();
            AddFood.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
            var Select = db.Foods.SingleOrDefault(x => x.Id == IdObj);

             Select.FoodName = FoodName.Text ;
             Select.FoodQuantity = int.Parse(FoodQuantity.Text) ;
             Select.FoodPrice = float.Parse(FoodPrice.Text) ;
             Select.FoodCategory = CategoryCombo.Text ;
             Select.CategoryId = int.Parse(CategoryCombo.SelectedValue.ToString());

            db.SaveChanges();
            MessageBox.Show("تم الحفظ بنجاح");
            UserGrid.DataSource = db.Foods.ToList();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("هل أنت متأكد من عملية الحذف ؟", "حذف الصنف", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
                var Select = db.Foods.SingleOrDefault(x => x.Id == IdObj);
                db.Foods.Remove(Select);

                db.SaveChanges();
                MessageBox.Show("Removed Successfully");
                UserGrid.DataSource = db.Foods.ToList();
            } 
            else if (dialogResult == DialogResult.No) { }
        }

        private void CategoryCombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FoodSearchField_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
