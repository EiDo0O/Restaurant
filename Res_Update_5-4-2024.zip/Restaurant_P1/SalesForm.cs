﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class SalesForm : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        public static SalesForm b1;
        public DataGridView g;

        public SalesForm()
        {
            InitializeComponent();
            //b1 = this;
            //g = SalesGrid;
            //db.Sales.Add(new Restraurant_P_1.DB.Sale
            //{
            //    SoldName = SalesFood.Sales1 ,
            //    SoldQuantity = SalesFood.Sales2.ToString()
            //}
            //   ) ;
            //db.SaveChanges();
            //SalesGrid.DataSource = db.Sales.ToList();
        }

        private void SalesForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'restaurantDataSet24.OrderList2' table. You can move, or remove it, as needed.
            this.orderList2TableAdapter3.Fill(this.restaurantDataSet24.OrderList2);
            // TODO: This line of code loads data into the 'restaurantDataSet23.OrderList2' table. You can move, or remove it, as needed.
            this.orderList2TableAdapter2.Fill(this.restaurantDataSet23.OrderList2);
            // TODO: This line of code loads data into the 'restaurantDataSet22.OrderList2' table. You can move, or remove it, as needed.
            this.orderList2TableAdapter1.Fill(this.restaurantDataSet22.OrderList2);
            // TODO: This line of code loads data into the 'restaurantDataSet20.OrderList2' table. You can move, or remove it, as needed.
            this.orderList2TableAdapter.Fill(this.restaurantDataSet20.OrderList2);
            // TODO: This line of code loads data into the 'restaurantDataSet19.OrderList' table. You can move, or remove it, as needed.
            this.orderListTableAdapter.Fill(this.restaurantDataSet19.OrderList);
            // TODO: This line of code loads data into the 'restaurantDataSet11.Sales' table. You can move, or remove it, as needed.
            this.salesTableAdapter.Fill(this.restaurantDataSet11.Sales);

        }
    }
}
