﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class AddCustomer : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        public AddCustomer()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("تم تسجيل عميل جديد");
            db.Customers.Add(new Restraurant_P_1.DB.Customer
            {
                CusName = CusName.Text,
                CusAddress = CusAdd.Text,
                CusPhone = int.Parse(CusPhoneNum.Text),
                CusEmail = CusEmail.Text,
            }
               );
            db.SaveChanges();
            this.Close();
        }
    }
}
