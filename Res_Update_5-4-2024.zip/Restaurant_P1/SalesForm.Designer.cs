﻿
namespace Restraurant_P_1
{
    partial class SalesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.salesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet11 = new Restraurant_P_1.RestaurantDataSet11();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.backgroundWorker2 = new System.ComponentModel.BackgroundWorker();
            this.button1 = new System.Windows.Forms.Button();
            this.salesTableAdapter = new Restraurant_P_1.RestaurantDataSet11TableAdapters.SalesTableAdapter();
            this.OrderGrid = new System.Windows.Forms.DataGridView();
            this.foodNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodQtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderList2BindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet24 = new Restraurant_P_1.RestaurantDataSet24();
            this.restaurantDataSet19 = new Restraurant_P_1.RestaurantDataSet19();
            this.orderListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.orderListTableAdapter = new Restraurant_P_1.RestaurantDataSet19TableAdapters.OrderListTableAdapter();
            this.restaurantDataSet20 = new Restraurant_P_1.RestaurantDataSet20();
            this.orderList2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.orderList2TableAdapter = new Restraurant_P_1.RestaurantDataSet20TableAdapters.OrderList2TableAdapter();
            this.restaurantDataSet22 = new Restraurant_P_1.RestaurantDataSet22();
            this.orderList2BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.orderList2TableAdapter1 = new Restraurant_P_1.RestaurantDataSet22TableAdapters.OrderList2TableAdapter();
            this.restaurantDataSet23 = new Restraurant_P_1.RestaurantDataSet23();
            this.orderList2BindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.orderList2TableAdapter2 = new Restraurant_P_1.RestaurantDataSet23TableAdapters.OrderList2TableAdapter();
            this.orderList2TableAdapter3 = new Restraurant_P_1.RestaurantDataSet24TableAdapters.OrderList2TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.salesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // salesBindingSource
            // 
            this.salesBindingSource.DataMember = "Sales";
            this.salesBindingSource.DataSource = this.restaurantDataSet11;
            // 
            // restaurantDataSet11
            // 
            this.restaurantDataSet11.DataSetName = "RestaurantDataSet11";
            this.restaurantDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Restraurant_P_1.Properties.Resources._601;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(142, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 35);
            this.button1.TabIndex = 99;
            this.button1.Text = "المبيعـات";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // salesTableAdapter
            // 
            this.salesTableAdapter.ClearBeforeFill = true;
            // 
            // OrderGrid
            // 
            this.OrderGrid.AllowUserToAddRows = false;
            this.OrderGrid.AutoGenerateColumns = false;
            this.OrderGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OrderGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.foodNameDataGridViewTextBoxColumn,
            this.foodQtyDataGridViewTextBoxColumn});
            this.OrderGrid.DataSource = this.orderList2BindingSource3;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.OrderGrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.OrderGrid.Location = new System.Drawing.Point(77, 73);
            this.OrderGrid.Name = "OrderGrid";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.OrderGrid.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.OrderGrid.Size = new System.Drawing.Size(243, 204);
            this.OrderGrid.TabIndex = 128;
            // 
            // foodNameDataGridViewTextBoxColumn
            // 
            this.foodNameDataGridViewTextBoxColumn.DataPropertyName = "FoodName";
            this.foodNameDataGridViewTextBoxColumn.HeaderText = "FoodName";
            this.foodNameDataGridViewTextBoxColumn.Name = "foodNameDataGridViewTextBoxColumn";
            // 
            // foodQtyDataGridViewTextBoxColumn
            // 
            this.foodQtyDataGridViewTextBoxColumn.DataPropertyName = "FoodQty";
            this.foodQtyDataGridViewTextBoxColumn.HeaderText = "FoodQty";
            this.foodQtyDataGridViewTextBoxColumn.Name = "foodQtyDataGridViewTextBoxColumn";
            // 
            // orderList2BindingSource3
            // 
            this.orderList2BindingSource3.DataMember = "OrderList2";
            this.orderList2BindingSource3.DataSource = this.restaurantDataSet24;
            // 
            // restaurantDataSet24
            // 
            this.restaurantDataSet24.DataSetName = "RestaurantDataSet24";
            this.restaurantDataSet24.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // restaurantDataSet19
            // 
            this.restaurantDataSet19.DataSetName = "RestaurantDataSet19";
            this.restaurantDataSet19.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // orderListBindingSource
            // 
            this.orderListBindingSource.DataMember = "OrderList";
            this.orderListBindingSource.DataSource = this.restaurantDataSet19;
            // 
            // orderListTableAdapter
            // 
            this.orderListTableAdapter.ClearBeforeFill = true;
            // 
            // restaurantDataSet20
            // 
            this.restaurantDataSet20.DataSetName = "RestaurantDataSet20";
            this.restaurantDataSet20.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // orderList2BindingSource
            // 
            this.orderList2BindingSource.DataMember = "OrderList2";
            this.orderList2BindingSource.DataSource = this.restaurantDataSet20;
            // 
            // orderList2TableAdapter
            // 
            this.orderList2TableAdapter.ClearBeforeFill = true;
            // 
            // restaurantDataSet22
            // 
            this.restaurantDataSet22.DataSetName = "RestaurantDataSet22";
            this.restaurantDataSet22.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // orderList2BindingSource1
            // 
            this.orderList2BindingSource1.DataMember = "OrderList2";
            this.orderList2BindingSource1.DataSource = this.restaurantDataSet22;
            // 
            // orderList2TableAdapter1
            // 
            this.orderList2TableAdapter1.ClearBeforeFill = true;
            // 
            // restaurantDataSet23
            // 
            this.restaurantDataSet23.DataSetName = "RestaurantDataSet23";
            this.restaurantDataSet23.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // orderList2BindingSource2
            // 
            this.orderList2BindingSource2.DataMember = "OrderList2";
            this.orderList2BindingSource2.DataSource = this.restaurantDataSet23;
            // 
            // orderList2TableAdapter2
            // 
            this.orderList2TableAdapter2.ClearBeforeFill = true;
            // 
            // orderList2TableAdapter3
            // 
            this.orderList2TableAdapter3.ClearBeforeFill = true;
            // 
            // SalesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._60;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(391, 300);
            this.Controls.Add(this.OrderGrid);
            this.Controls.Add(this.button1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(407, 339);
            this.MinimumSize = new System.Drawing.Size(407, 339);
            this.Name = "SalesForm";
            this.Text = "SalesForm";
            this.Load += new System.EventHandler(this.SalesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.salesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OrderGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderList2BindingSource2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.ComponentModel.BackgroundWorker backgroundWorker2;
        private System.Windows.Forms.Button button1;
        private RestaurantDataSet11 restaurantDataSet11;
        private System.Windows.Forms.BindingSource salesBindingSource;
        private RestaurantDataSet11TableAdapters.SalesTableAdapter salesTableAdapter;
        private System.Windows.Forms.DataGridView OrderGrid;
        private RestaurantDataSet19 restaurantDataSet19;
        private System.Windows.Forms.BindingSource orderListBindingSource;
        private RestaurantDataSet19TableAdapters.OrderListTableAdapter orderListTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodQtyDataGridViewTextBoxColumn;
        private RestaurantDataSet20 restaurantDataSet20;
        private System.Windows.Forms.BindingSource orderList2BindingSource;
        private RestaurantDataSet20TableAdapters.OrderList2TableAdapter orderList2TableAdapter;
        private RestaurantDataSet22 restaurantDataSet22;
        private System.Windows.Forms.BindingSource orderList2BindingSource1;
        private RestaurantDataSet22TableAdapters.OrderList2TableAdapter orderList2TableAdapter1;
        private RestaurantDataSet23 restaurantDataSet23;
        private System.Windows.Forms.BindingSource orderList2BindingSource2;
        private RestaurantDataSet23TableAdapters.OrderList2TableAdapter orderList2TableAdapter2;
        private RestaurantDataSet24 restaurantDataSet24;
        private System.Windows.Forms.BindingSource orderList2BindingSource3;
        private RestaurantDataSet24TableAdapters.OrderList2TableAdapter orderList2TableAdapter3;
    }
}