﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class Bill : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        /*
        public static Bill b1;
        public TextBox tb1 , tb2 , tb3 ;
        */

        string OrderType = "";
       

        private void user_name_Click(object sender, EventArgs e)
        {

        }

        private void UserPhone_Click(object sender, EventArgs e)
        {

        }

        private void Bill_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'restaurantDataSet25.OrderList2' table. You can move, or remove it, as needed.
            this.orderList2TableAdapter.Fill(this.restaurantDataSet25.OrderList2);
            // TODO: This line of code loads data into the 'restaurantDataSet21.OrderList2' table. You can move, or remove it, as needed.
            // TODO: This line of code loads data into the 'restaurantDataSet18.OrderList' table. You can move, or remove it, as needed.
            this.orderListTableAdapter.Fill(this.restaurantDataSet18.OrderList);
            // TODO: This line of code loads data into the 'restaurantDataSet17.Food' table. You can move, or remove it, as needed.
            this.foodTableAdapter.Fill(this.restaurantDataSet17.Food);

        }

        private void UserGrid_SelectionChanged(object sender, EventArgs e)
        {
            
            try
            {
                int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
                var Select = db.Foods.SingleOrDefault(x => x.Id == IdObj);

                FoodNameBill.Text = Select.FoodName ;
            }
            catch { }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            DateTimeBox.Text = DateTime.Now.ToString();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            
            if (FoodQuantityBill.Text != "")
            {
                int Quantity = int.Parse(FoodQuantityBill.Text);
                int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
                var Select = db.Foods.SingleOrDefault(x => x.Id == IdObj);
                db.OrderLists.Add(new Restraurant_P_1.DB.OrderList
                {
                    FoodName = Select.FoodName,
                    FoodQty = int.Parse(FoodQuantityBill.Text),
                    Price = (Select.FoodPrice) * Quantity
                }
                    );

                db.OrderList2.Add(new Restraurant_P_1.DB.OrderList2
                {
                    FoodName = Select.FoodName,
                    FoodQty = int.Parse(FoodQuantityBill.Text)
                }
                    );
                
                Select.FoodQuantity = Select.FoodQuantity - int.Parse(FoodQuantityBill.Text);


                db.SaveChanges();
                OrderGrid.DataSource = db.OrderLists.ToList();
                UserGrid.DataSource = db.Foods.ToList();

                float sum= 0;
                int Count = OrderGrid.Rows.Count;
              //Total.Text = "0";
                for (int i = 0; i < Count ; i++)
                {
                    //  Total.Text = (float.Parse(Total.Text) + float.Parse(OrderGrid.Rows[i].Cells[3].Value.ToString())).ToString();
                    sum += float.Parse(OrderGrid.Rows[i].Cells[3].Value.ToString());
                }
                Total.Text = sum.ToString();
            } else
            {
                    MessageBox.Show("من فضلك أدخل الكمية أولا");
            }
            // SalesForm.b1.g = OrderGrid;
            /*
            SalesFood.Sales1 = Select.FoodName;
            SalesFood.Sales2 = int.Parse(FoodQuantityBill.Text);
        */
            }

        private void button1_Click(object sender, EventArgs e)
        {
            int IdObj2 = int.Parse(OrderGrid.CurrentRow.Cells[0].Value.ToString());
            var Select2 = db.OrderLists.SingleOrDefault(x => x.Id == IdObj2);
            if (OrderGrid.Rows.Count != 1)
            {
                Total.Text = (float.Parse(Total.Text) - Select2.Price).ToString();

                
                int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
                var Select = db.Foods.SingleOrDefault(x => x.Id == IdObj);

                // Select.FoodQuantity = Select.FoodQuantity + Select2.FoodQty ;

                int j = 0;
                for (j = 0;  j < UserGrid.Rows.Count ;j++)
                {
                    if (Select2.FoodName == UserGrid.Rows[j].Cells[1].Value.ToString())
                    {
                        UserGrid.Rows[j].Cells[2].Value = (int.Parse(UserGrid.Rows[j].Cells[2].Value.ToString()) + Select2.FoodQty).ToString();
                    }
                }

                db.OrderLists.Remove(Select2);

                db.SaveChanges();
                OrderGrid.DataSource = db.OrderLists.ToList();
                UserGrid.DataSource = db.Foods.ToList();
            } else
            {
               
                Total.Text = (float.Parse(Total.Text) - Select2.Price).ToString();
                db.OrderLists.Remove(Select2);

                int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
                var Select = db.Foods.SingleOrDefault(x => x.Id == IdObj);
                Select.FoodQuantity = Select.FoodQuantity + Select2.FoodQty;


                db.SaveChanges();
                OrderGrid.DataSource = db.OrderLists.ToList();
                UserGrid.DataSource = db.Foods.ToList();
                Total.Text = "0.00";
            }
            
                //int RowIndex = SalesForm.b1.g.Rows.Count - 1;
                //int IdObj3 = int.Parse(SalesForm.b1.g.Rows[RowIndex].Cells[0].Value.ToString());
                //var Select3 = db.Sales.SingleOrDefault(x => x.Id == IdObj3);
                //db.Sales.Remove(Select3);
                //SalesForm.b1.g.DataSource = db.Sales.ToList();
            }

        private void Sale_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void Sale_Enter(object sender, EventArgs e)
        {
            
        }

        private void Sale_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && Sale.Text != "")
                    Total.Text = (float.Parse(Total.Text) - (float.Parse(Total.Text) * float.Parse(Sale.Text) / 100)).ToString();
        }
        
        private void Print_Click(object sender, EventArgs e)
        {
            if (CusNameBill.Text == "" || CusPhoneBill.Text == "" || CusAddBill.Text == "" || FoodNameBill.Text == "" || FoodQuantityBill.Text == "")
            {
                MessageBox.Show("من فضلك أكمل إدخال البيانات ");
                return;
            }
            
            MessageBox.Show("                      Show Hut ! " + "\n" + "\n" + "Date / Time: " + DateTimeBox.Text + "\n" + "Order Type: " + OrderType + "\n" + "Cashier Name: " + CashName.Text + "\n" + "Customer Name: " + CusNameBill.Text + "\n" + "Customer Phone: " + CusPhoneBill.Text + "\n" + "Customer Address: " + CusAddBill.Text + "\n" + "Food Ordered: " +  FoodNameBill.Text + "\n" + "Sale: " + Sale.Text + "\n" + "Total: " + Total.Text);          
            for (int x = 0; x < OrderGrid.Rows.Count; x++)
            {
                int IdObj3 = int.Parse(OrderGrid.Rows[x].Cells[0].Value.ToString());
                var Select3 = db.OrderLists.SingleOrDefault(y => y.Id == IdObj3);
                db.OrderLists.Remove(Select3);
            }
            db.SaveChanges();
            OrderGrid.DataSource = db.OrderLists.ToList();

            Budget.budget = Budget.budget + float.Parse(Total.Text);

            var CheckCustomer = db.Customers.FirstOrDefault(u => u.CusName == CusNameBill.Text && u.CusAddress == CusAddBill.Text && u.CusPhone.ToString() == CusPhoneBill.Text);

            if (CheckCustomer == null) {
                db.Customers.Add(new Restraurant_P_1.DB.Customer
                {
                    CusName = CusNameBill.Text,
                    CusAddress = CusAddBill.Text,
                    CusPhone = Convert.ToInt32(CusPhoneBill.Text)
                }
                );
                db.SaveChanges();
            }
            if (Delivery.Checked == true)
            {
                db.Deliveries.Add(new Restraurant_P_1.DB.Delivery
                {
                    OrderName = CusNameBill.Text,
                    OrderDate = Convert.ToDateTime(DateTimeBox.Text)
                }
                );
                db.SaveChanges();

            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Foods.Where(x => x.FoodName.Contains(FoodSearchField.Text)).ToList();
            if (FoodSearchField.Text == "")
            {
                UserGrid.DataSource = db.Foods.ToList();
            }
        }

        private void Home_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new MainForm());
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (Indoor.Checked == true)
            {
                OrderType = "Indoor";
            }
        }

        private void TakeAway_CheckedChanged(object sender, EventArgs e)
        {
            if (TakeAway.Checked == true)
            {
                OrderType = "Take Away";
            }
        }

        private void Delivery_CheckedChanged(object sender, EventArgs e)
        {
            if (Delivery.Checked == true)
            {
                OrderType = "Delivery";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Foods.ToList();
        }
        /*
        public Bill()
        {
            InitializeComponent();
            
            b1 = this;    
            tb1 = CusNameBill;
            tb2 = CusPhoneBill;
            tb3 = CusAddBill;
            
            //CashName.Text = UserReg.Name;

        }
    */

        public Bill(string CusNameBill = null, string CusPhoneBill =null, string CusAddBill=null)
        {
            InitializeComponent();

            this.CusNameBill.Text = CusNameBill;
            this.CusPhoneBill.Text = CusPhoneBill;
            this.CusAddBill.Text = CusAddBill;

            this.Indoor.Select();

            /*
            this.text1 = text1;
            this.text2 = text2;
            this.text3 = text3;
            */
            CashName.Text = UserReg.Name;

        }

        private void BillName_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
    static public class Budget
    {
        static public float budget { get; set; }
    }
    static public class SalesFood
    {
        static public string Sales1 { get; set; }
        static public int Sales2 { get; set; }
        static public string Delete1 { get; set; }
        static public int Delete2 { get; set; }
    }
}
