﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class StuffInfo : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        public StuffInfo()
        {
            InitializeComponent();
            UserGrid.DataSource = db.Stuff1.ToList();
        }



      

        private void button2_Click(object sender, EventArgs e)
        {
            int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
            var Select = db.Stuff1.SingleOrDefault(x => x.Id == IdObj);

            Select.StuffName = StuffName.Text;
            Select.StuffCategory = StuffCategory.Text;
            Select.StuffPhone = int.Parse(StuffPhoneNum.Text);
            Select.StuffSalary = float.Parse(StuffSalary.Text);
            Select.StuffEmail = StuffEmail.Text;
            Select.StuffAddress = StuffAdd.Text;

            db.SaveChanges();
            MessageBox.Show("Saved Successfully");
            UserGrid.DataSource = db.Stuff1.ToList();
        }

        private void user_name_Click(object sender, EventArgs e)
        {

        }

       

       

        private void button1_Click(object sender, EventArgs e)
        {

        }

      
        private void button4_Click_1(object sender, EventArgs e)
        {
            AddStuff AddStuff = new AddStuff();
            AddStuff.Show();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
            var Select = db.Stuff1.SingleOrDefault(x => x.Id == IdObj);
            db.Stuff1.Remove(Select);

            db.SaveChanges();
            MessageBox.Show("Removed Successfully");
            UserGrid.DataSource = db.Stuff1.ToList();
        }

        private void Home_Click_1(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new MainForm());

        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Stuff1.ToList();

        }

        private void UserGrid_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
                var Select = db.Stuff1.SingleOrDefault(x => x.Id == IdObj);

                StuffName.Text = Select.StuffName;
                StuffCategory.Text = Select.StuffCategory;
                StuffPhoneNum.Text = Select.StuffPhone.ToString();
                StuffSalary.Text = Select.StuffSalary.ToString();
                StuffEmail.Text = Select.StuffEmail;
                StuffAdd.Text = Select.StuffAddress;
            }
            catch { }

        }
    }
}
