﻿using Restraurant_P_1.DB;

namespace Restraurant_P_1
{
    internal class RestaurantEnteties : RestaurantEntities
    {
    }
}