﻿
namespace Restraurant_P_1
{
    partial class MenuShow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.FoodPrice = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.UserGrid = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodCategoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet6 = new Restraurant_P_1.RestaurantDataSet6();
            this.foodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet5 = new Restraurant_P_1.RestaurantDataSet5();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.FoodQuantity = new System.Windows.Forms.TextBox();
            this.UserPhone = new System.Windows.Forms.Label();
            this.FoodName = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.Label();
            this.user_name = new System.Windows.Forms.Label();
            this.Refresh = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Home = new System.Windows.Forms.Button();
            this.foodTableAdapter = new Restraurant_P_1.RestaurantDataSet5TableAdapters.FoodTableAdapter();
            this.CategoryCombo = new System.Windows.Forms.ComboBox();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet7 = new Restraurant_P_1.RestaurantDataSet7();
            this.foodTableAdapter1 = new Restraurant_P_1.RestaurantDataSet6TableAdapters.FoodTableAdapter();
            this.categoryTableAdapter = new Restraurant_P_1.RestaurantDataSet7TableAdapters.CategoryTableAdapter();
            this.FoodSearchField = new System.Windows.Forms.TextBox();
            this.SearchButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet7)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(207, 227);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 14);
            this.label5.TabIndex = 107;
            this.label5.Text = "السعر";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(209, 171);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 14);
            this.label4.TabIndex = 106;
            // 
            // FoodPrice
            // 
            this.FoodPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FoodPrice.Location = new System.Drawing.Point(102, 218);
            this.FoodPrice.Multiline = true;
            this.FoodPrice.Name = "FoodPrice";
            this.FoodPrice.Size = new System.Drawing.Size(66, 30);
            this.FoodPrice.TabIndex = 105;
            this.FoodPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(12, 314);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 16);
            this.label3.TabIndex = 103;
            this.label3.Text = "حذف";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(203, 315);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 102;
            this.label2.Text = "إضافة";
            // 
            // UserGrid
            // 
            this.UserGrid.AutoGenerateColumns = false;
            this.UserGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UserGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.foodNameDataGridViewTextBoxColumn,
            this.foodQuantityDataGridViewTextBoxColumn,
            this.foodCategoryDataGridViewTextBoxColumn,
            this.foodPriceDataGridViewTextBoxColumn});
            this.UserGrid.DataSource = this.foodBindingSource1;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.UserGrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.UserGrid.Location = new System.Drawing.Point(284, 39);
            this.UserGrid.Name = "UserGrid";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.UserGrid.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.UserGrid.Size = new System.Drawing.Size(506, 304);
            this.UserGrid.TabIndex = 99;
            this.UserGrid.SelectionChanged += new System.EventHandler(this.UserGrid_SelectionChanged);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 70;
            // 
            // foodNameDataGridViewTextBoxColumn
            // 
            this.foodNameDataGridViewTextBoxColumn.DataPropertyName = "FoodName";
            this.foodNameDataGridViewTextBoxColumn.HeaderText = "FoodName";
            this.foodNameDataGridViewTextBoxColumn.Name = "foodNameDataGridViewTextBoxColumn";
            // 
            // foodQuantityDataGridViewTextBoxColumn
            // 
            this.foodQuantityDataGridViewTextBoxColumn.DataPropertyName = "FoodQuantity";
            this.foodQuantityDataGridViewTextBoxColumn.HeaderText = "FoodQuantity";
            this.foodQuantityDataGridViewTextBoxColumn.Name = "foodQuantityDataGridViewTextBoxColumn";
            // 
            // foodCategoryDataGridViewTextBoxColumn
            // 
            this.foodCategoryDataGridViewTextBoxColumn.DataPropertyName = "FoodCategory";
            this.foodCategoryDataGridViewTextBoxColumn.HeaderText = "FoodCategory";
            this.foodCategoryDataGridViewTextBoxColumn.Name = "foodCategoryDataGridViewTextBoxColumn";
            // 
            // foodPriceDataGridViewTextBoxColumn
            // 
            this.foodPriceDataGridViewTextBoxColumn.DataPropertyName = "FoodPrice";
            this.foodPriceDataGridViewTextBoxColumn.HeaderText = "FoodPrice";
            this.foodPriceDataGridViewTextBoxColumn.Name = "foodPriceDataGridViewTextBoxColumn";
            // 
            // foodBindingSource1
            // 
            this.foodBindingSource1.DataMember = "Food";
            this.foodBindingSource1.DataSource = this.restaurantDataSet6;
            // 
            // restaurantDataSet6
            // 
            this.restaurantDataSet6.DataSetName = "RestaurantDataSet6";
            this.restaurantDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodBindingSource
            // 
            this.foodBindingSource.DataMember = "Food";
            this.foodBindingSource.DataSource = this.restaurantDataSet5;
            // 
            // restaurantDataSet5
            // 
            this.restaurantDataSet5.DataSetName = "RestaurantDataSet5";
            this.restaurantDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(475, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 27);
            this.label1.TabIndex = 97;
            this.label1.Text = "قائمة الطعام";
            // 
            // button2
            // 
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(99, 283);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(83, 32);
            this.button2.TabIndex = 96;
            this.button2.Text = "حفظ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FoodQuantity
            // 
            this.FoodQuantity.Location = new System.Drawing.Point(15, 127);
            this.FoodQuantity.Multiline = true;
            this.FoodQuantity.Name = "FoodQuantity";
            this.FoodQuantity.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.FoodQuantity.Size = new System.Drawing.Size(153, 18);
            this.FoodQuantity.TabIndex = 93;
            // 
            // UserPhone
            // 
            this.UserPhone.AutoSize = true;
            this.UserPhone.BackColor = System.Drawing.Color.Transparent;
            this.UserPhone.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserPhone.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.UserPhone.Location = new System.Drawing.Point(209, 130);
            this.UserPhone.Name = "UserPhone";
            this.UserPhone.Size = new System.Drawing.Size(40, 14);
            this.UserPhone.TabIndex = 91;
            this.UserPhone.Text = "الكمية";
            // 
            // FoodName
            // 
            this.FoodName.Location = new System.Drawing.Point(15, 83);
            this.FoodName.Multiline = true;
            this.FoodName.Name = "FoodName";
            this.FoodName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.FoodName.Size = new System.Drawing.Size(153, 18);
            this.FoodName.TabIndex = 89;
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.BackColor = System.Drawing.Color.Transparent;
            this.password.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.password.Location = new System.Drawing.Point(197, 174);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(68, 14);
            this.password.TabIndex = 88;
            this.password.Text = "القسم\\الفئة";
            // 
            // user_name
            // 
            this.user_name.AutoSize = true;
            this.user_name.BackColor = System.Drawing.Color.Transparent;
            this.user_name.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.user_name.Location = new System.Drawing.Point(196, 85);
            this.user_name.Name = "user_name";
            this.user_name.Size = new System.Drawing.Size(64, 14);
            this.user_name.TabIndex = 87;
            this.user_name.Text = "اسم الصنف";
            // 
            // Refresh
            // 
            this.Refresh.BackgroundImage = global::Restraurant_P_1.Properties.Resources._30;
            this.Refresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Refresh.Location = new System.Drawing.Point(41, 4);
            this.Refresh.Name = "Refresh";
            this.Refresh.Size = new System.Drawing.Size(34, 30);
            this.Refresh.TabIndex = 108;
            this.Refresh.UseVisualStyleBackColor = true;
            this.Refresh.Click += new System.EventHandler(this.Refresh_Click);
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::Restraurant_P_1.Properties.Resources.download81;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Location = new System.Drawing.Point(12, 283);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 32);
            this.button5.TabIndex = 101;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::Restraurant_P_1.Properties.Resources.download112;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Location = new System.Drawing.Point(207, 283);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(35, 32);
            this.button4.TabIndex = 100;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::Restraurant_P_1.Properties.Resources.imag1;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Location = new System.Drawing.Point(587, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 32);
            this.button3.TabIndex = 98;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Restraurant_P_1.Properties.Resources._35;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(67, 283);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 32);
            this.button1.TabIndex = 95;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Home
            // 
            this.Home.BackgroundImage = global::Restraurant_P_1.Properties.Resources._34;
            this.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.Location = new System.Drawing.Point(2, 2);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(33, 32);
            this.Home.TabIndex = 86;
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // foodTableAdapter
            // 
            this.foodTableAdapter.ClearBeforeFill = true;
            // 
            // CategoryCombo
            // 
            this.CategoryCombo.DataSource = this.categoryBindingSource;
            this.CategoryCombo.DisplayMember = "Category";
            this.CategoryCombo.FormattingEnabled = true;
            this.CategoryCombo.Location = new System.Drawing.Point(47, 170);
            this.CategoryCombo.Name = "CategoryCombo";
            this.CategoryCombo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CategoryCombo.Size = new System.Drawing.Size(121, 21);
            this.CategoryCombo.TabIndex = 109;
            this.CategoryCombo.ValueMember = "Id";
            this.CategoryCombo.SelectedIndexChanged += new System.EventHandler(this.CategoryCombo_SelectedIndexChanged);
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.restaurantDataSet7;
            // 
            // restaurantDataSet7
            // 
            this.restaurantDataSet7.DataSetName = "RestaurantDataSet7";
            this.restaurantDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // foodTableAdapter1
            // 
            this.foodTableAdapter1.ClearBeforeFill = true;
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // FoodSearchField
            // 
            this.FoodSearchField.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FoodSearchField.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.FoodSearchField.Location = new System.Drawing.Point(80, 8);
            this.FoodSearchField.Multiline = true;
            this.FoodSearchField.Name = "FoodSearchField";
            this.FoodSearchField.Size = new System.Drawing.Size(134, 24);
            this.FoodSearchField.TabIndex = 111;
            this.FoodSearchField.Text = " اسم الطعام  ";
            this.FoodSearchField.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.FoodSearchField.TextChanged += new System.EventHandler(this.FoodSearchField_TextChanged);
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.Color.Transparent;
            this.SearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SearchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SearchButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SearchButton.Location = new System.Drawing.Point(215, 8);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(53, 24);
            this.SearchButton.TabIndex = 110;
            this.SearchButton.Text = "بحث";
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // MenuShow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._71;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 350);
            this.Controls.Add(this.FoodSearchField);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.CategoryCombo);
            this.Controls.Add(this.Refresh);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.FoodPrice);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.UserGrid);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.FoodQuantity);
            this.Controls.Add(this.UserPhone);
            this.Controls.Add(this.FoodName);
            this.Controls.Add(this.password);
            this.Controls.Add(this.user_name);
            this.Controls.Add(this.Home);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(816, 389);
            this.MinimumSize = new System.Drawing.Size(816, 389);
            this.Name = "MenuShow";
            this.Text = "Menu";
            this.Load += new System.EventHandler(this.MenuShow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Refresh;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox FoodPrice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView UserGrid;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox FoodQuantity;
        private System.Windows.Forms.Label UserPhone;
        private System.Windows.Forms.TextBox FoodName;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Label user_name;
        private System.Windows.Forms.Button Home;
        private RestaurantDataSet5 restaurantDataSet5;
        private System.Windows.Forms.BindingSource foodBindingSource;
        private RestaurantDataSet5TableAdapters.FoodTableAdapter foodTableAdapter;
        private System.Windows.Forms.ComboBox CategoryCombo;
        private RestaurantDataSet6 restaurantDataSet6;
        private System.Windows.Forms.BindingSource foodBindingSource1;
        private RestaurantDataSet6TableAdapters.FoodTableAdapter foodTableAdapter1;
        private RestaurantDataSet7 restaurantDataSet7;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private RestaurantDataSet7TableAdapters.CategoryTableAdapter categoryTableAdapter;
        private System.Windows.Forms.TextBox FoodSearchField;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodCategoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodPriceDataGridViewTextBoxColumn;
    }
}