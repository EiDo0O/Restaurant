﻿
namespace Restraurant_P_1
{
    partial class CasePass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PW = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.PwButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // PW
            // 
            this.PW.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PW.Location = new System.Drawing.Point(89, 57);
            this.PW.MaxLength = 3;
            this.PW.Multiline = true;
            this.PW.Name = "PW";
            this.PW.PasswordChar = '*';
            this.PW.Size = new System.Drawing.Size(89, 43);
            this.PW.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(212, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 34);
            this.label1.TabIndex = 100;
            this.label1.Text = "الرقم السري";
            // 
            // PwButton
            // 
            this.PwButton.BackColor = System.Drawing.Color.Transparent;
            this.PwButton.BackgroundImage = global::Restraurant_P_1.Properties.Resources._55;
            this.PwButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PwButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PwButton.FlatAppearance.BorderSize = 0;
            this.PwButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PwButton.Location = new System.Drawing.Point(12, 50);
            this.PwButton.Name = "PwButton";
            this.PwButton.Size = new System.Drawing.Size(67, 55);
            this.PwButton.TabIndex = 101;
            this.PwButton.UseVisualStyleBackColor = false;
            this.PwButton.Click += new System.EventHandler(this.PwButton_Click);
            // 
            // CasePass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._54;
            this.ClientSize = new System.Drawing.Size(384, 159);
            this.Controls.Add(this.PwButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.PW);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(400, 198);
            this.MinimumSize = new System.Drawing.Size(400, 198);
            this.Name = "CasePass";
            this.Text = "CasePass";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox PW;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button PwButton;
    }
}