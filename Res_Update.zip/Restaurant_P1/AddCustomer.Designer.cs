﻿
namespace Restraurant_P_1
{
    partial class AddCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CusAdd = new System.Windows.Forms.TextBox();
            this.CusEmail = new System.Windows.Forms.TextBox();
            this.CusPhoneNum = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.Label();
            this.UserPhone = new System.Windows.Forms.Label();
            this.CusName = new System.Windows.Forms.TextBox();
            this.user_name = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(133, 194);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(83, 32);
            this.button2.TabIndex = 94;
            this.button2.Text = "حفظ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(69, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 27);
            this.label1.TabIndex = 91;
            this.label1.Text = "إضافة عميل جديد";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(250, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 14);
            this.label4.TabIndex = 89;
            this.label4.Text = "العنوان";
            // 
            // CusAdd
            // 
            this.CusAdd.Location = new System.Drawing.Point(55, 127);
            this.CusAdd.Multiline = true;
            this.CusAdd.Name = "CusAdd";
            this.CusAdd.Size = new System.Drawing.Size(153, 18);
            this.CusAdd.TabIndex = 87;
            // 
            // CusEmail
            // 
            this.CusEmail.Location = new System.Drawing.Point(55, 156);
            this.CusEmail.Multiline = true;
            this.CusEmail.Name = "CusEmail";
            this.CusEmail.Size = new System.Drawing.Size(153, 18);
            this.CusEmail.TabIndex = 86;
            // 
            // CusPhoneNum
            // 
            this.CusPhoneNum.Location = new System.Drawing.Point(55, 103);
            this.CusPhoneNum.Multiline = true;
            this.CusPhoneNum.Name = "CusPhoneNum";
            this.CusPhoneNum.Size = new System.Drawing.Size(153, 18);
            this.CusPhoneNum.TabIndex = 85;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.BackColor = System.Drawing.Color.Transparent;
            this.email.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.email.Location = new System.Drawing.Point(215, 156);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(98, 14);
            this.email.TabIndex = 84;
            this.email.Text = "البريد الإلكتروني";
            // 
            // UserPhone
            // 
            this.UserPhone.AutoSize = true;
            this.UserPhone.BackColor = System.Drawing.Color.Transparent;
            this.UserPhone.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserPhone.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.UserPhone.Location = new System.Drawing.Point(232, 105);
            this.UserPhone.Name = "UserPhone";
            this.UserPhone.Size = new System.Drawing.Size(73, 14);
            this.UserPhone.TabIndex = 83;
            this.UserPhone.Text = "رقم التليفون";
            // 
            // CusName
            // 
            this.CusName.Location = new System.Drawing.Point(55, 76);
            this.CusName.Multiline = true;
            this.CusName.Name = "CusName";
            this.CusName.Size = new System.Drawing.Size(153, 18);
            this.CusName.TabIndex = 81;
            // 
            // user_name
            // 
            this.user_name.AutoSize = true;
            this.user_name.BackColor = System.Drawing.Color.Transparent;
            this.user_name.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.user_name.Location = new System.Drawing.Point(236, 78);
            this.user_name.Name = "user_name";
            this.user_name.Size = new System.Drawing.Size(65, 14);
            this.user_name.TabIndex = 79;
            this.user_name.Text = "اسم العميل";
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Restraurant_P_1.Properties.Resources._35;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(101, 194);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 32);
            this.button1.TabIndex = 93;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::Restraurant_P_1.Properties.Resources.download31;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Location = new System.Drawing.Point(222, 13);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 32);
            this.button3.TabIndex = 92;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // AddCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._70;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(329, 256);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CusAdd);
            this.Controls.Add(this.CusEmail);
            this.Controls.Add(this.CusPhoneNum);
            this.Controls.Add(this.email);
            this.Controls.Add(this.UserPhone);
            this.Controls.Add(this.CusName);
            this.Controls.Add(this.user_name);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(345, 295);
            this.MinimumSize = new System.Drawing.Size(345, 295);
            this.Name = "AddCustomer";
            this.Text = "AddCustomer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox CusAdd;
        public System.Windows.Forms.TextBox CusEmail;
        public System.Windows.Forms.TextBox CusPhoneNum;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label UserPhone;
        public System.Windows.Forms.TextBox CusName;
        private System.Windows.Forms.Label user_name;
    }
}