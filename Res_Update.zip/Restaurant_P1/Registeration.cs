﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class Registeration : Form
    {
        RestaurantEnteties db = new RestaurantEnteties() ;
        public static Registeration b1;
        public Registeration()
        {
            InitializeComponent();
            b1 = this;
        }
        
        private void log_in_Click(object sender, EventArgs e)
        {
            var CheckUser = db.Users.FirstOrDefault(x => x.UserName == UserName.Text && x.UserPassword == UserPW.Text);
            if (UserName.Text == "" && UserPW.Text == "")
            {
                MessageBox.Show("Fields are empty. Please enter data !");
            }
            else if (CheckUser != null)
            {
                MessageBox.Show("Welcome " + UserName.Text);
                
                this.Close();
                Thread th = new Thread(OpenNewForm);
                th.SetApartmentState(ApartmentState.STA);
                th.Start();

                UserReg.Name = CheckUser.UserName;
            }
            else
            {
                MessageBox.Show("User name or password is invalid. Please try again ! " );
            }
        }

        void OpenNewForm()
        {
            Application.Run(new MainForm());
        }
    }
    static public class UserReg
    {
        static public string Name { get; set; }
    }
}
