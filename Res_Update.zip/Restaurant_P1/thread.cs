﻿using System;

namespace Restraurant_P_1
{
    internal class thread
    {
        internal void setapartmentstate(object sta)
        {
            throw new NotImplementedException();
        }
    }
}