﻿
namespace Restraurant_P_1
{
    partial class StuffInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.StuffSalary = new System.Windows.Forms.TextBox();
            this.StuffAdd = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.UserGrid = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.StuffEmail = new System.Windows.Forms.TextBox();
            this.StuffPhoneNum = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.Label();
            this.UserPhone = new System.Windows.Forms.Label();
            this.StuffCategory = new System.Windows.Forms.TextBox();
            this.StuffName = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.Label();
            this.user_name = new System.Windows.Forms.Label();
            this.Home = new System.Windows.Forms.Button();
            this.Refresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(216, 241);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 14);
            this.label5.TabIndex = 84;
            this.label5.Text = "المرتب";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(218, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 14);
            this.label4.TabIndex = 83;
            this.label4.Text = "العنوان";
            // 
            // StuffSalary
            // 
            this.StuffSalary.Location = new System.Drawing.Point(111, 232);
            this.StuffSalary.Multiline = true;
            this.StuffSalary.Name = "StuffSalary";
            this.StuffSalary.Size = new System.Drawing.Size(66, 30);
            this.StuffSalary.TabIndex = 82;
            // 
            // StuffAdd
            // 
            this.StuffAdd.Location = new System.Drawing.Point(23, 174);
            this.StuffAdd.Multiline = true;
            this.StuffAdd.Name = "StuffAdd";
            this.StuffAdd.Size = new System.Drawing.Size(153, 18);
            this.StuffAdd.TabIndex = 81;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(21, 322);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 16);
            this.label3.TabIndex = 80;
            this.label3.Text = "حذف";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(212, 323);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 16);
            this.label2.TabIndex = 79;
            this.label2.Text = "إضافة";
            // 
            // button5
            // 
            this.button5.BackgroundImage = global::Restraurant_P_1.Properties.Resources.download81;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Location = new System.Drawing.Point(21, 291);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 32);
            this.button5.TabIndex = 78;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::Restraurant_P_1.Properties.Resources.download112;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Location = new System.Drawing.Point(216, 291);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(35, 32);
            this.button4.TabIndex = 77;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // UserGrid
            // 
            this.UserGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.UserGrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.UserGrid.Location = new System.Drawing.Point(291, 42);
            this.UserGrid.Name = "UserGrid";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.UserGrid.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.UserGrid.Size = new System.Drawing.Size(725, 304);
            this.UserGrid.TabIndex = 76;
            this.UserGrid.SelectionChanged += new System.EventHandler(this.UserGrid_SelectionChanged);
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::Restraurant_P_1.Properties.Resources.download102;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Location = new System.Drawing.Point(710, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 32);
            this.button3.TabIndex = 75;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(583, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 27);
            this.label1.TabIndex = 74;
            this.label1.Text = "بيانات العاملين";
            // 
            // button2
            // 
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button2.Location = new System.Drawing.Point(108, 291);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(83, 32);
            this.button2.TabIndex = 73;
            this.button2.Text = "حفظ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Restraurant_P_1.Properties.Resources._35;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Location = new System.Drawing.Point(76, 291);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 32);
            this.button1.TabIndex = 72;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // StuffEmail
            // 
            this.StuffEmail.Location = new System.Drawing.Point(24, 203);
            this.StuffEmail.Multiline = true;
            this.StuffEmail.Name = "StuffEmail";
            this.StuffEmail.Size = new System.Drawing.Size(153, 18);
            this.StuffEmail.TabIndex = 71;
            // 
            // StuffPhoneNum
            // 
            this.StuffPhoneNum.Location = new System.Drawing.Point(24, 115);
            this.StuffPhoneNum.Multiline = true;
            this.StuffPhoneNum.Name = "StuffPhoneNum";
            this.StuffPhoneNum.Size = new System.Drawing.Size(153, 18);
            this.StuffPhoneNum.TabIndex = 70;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.BackColor = System.Drawing.Color.Transparent;
            this.email.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.email.Location = new System.Drawing.Point(183, 203);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(98, 14);
            this.email.TabIndex = 69;
            this.email.Text = "البريد الإلكتروني";
            // 
            // UserPhone
            // 
            this.UserPhone.AutoSize = true;
            this.UserPhone.BackColor = System.Drawing.Color.Transparent;
            this.UserPhone.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserPhone.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.UserPhone.Location = new System.Drawing.Point(201, 117);
            this.UserPhone.Name = "UserPhone";
            this.UserPhone.Size = new System.Drawing.Size(73, 14);
            this.UserPhone.TabIndex = 68;
            this.UserPhone.Text = "رقم التليفون";
            // 
            // StuffCategory
            // 
            this.StuffCategory.Location = new System.Drawing.Point(24, 144);
            this.StuffCategory.Multiline = true;
            this.StuffCategory.Name = "StuffCategory";
            this.StuffCategory.Size = new System.Drawing.Size(153, 18);
            this.StuffCategory.TabIndex = 67;
            // 
            // StuffName
            // 
            this.StuffName.Location = new System.Drawing.Point(24, 88);
            this.StuffName.Multiline = true;
            this.StuffName.Name = "StuffName";
            this.StuffName.Size = new System.Drawing.Size(153, 18);
            this.StuffName.TabIndex = 66;
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.BackColor = System.Drawing.Color.Transparent;
            this.password.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.password.Location = new System.Drawing.Point(206, 147);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(68, 14);
            this.password.TabIndex = 65;
            this.password.Text = "القسم\\الفئة";
            // 
            // user_name
            // 
            this.user_name.AutoSize = true;
            this.user_name.BackColor = System.Drawing.Color.Transparent;
            this.user_name.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.user_name.Location = new System.Drawing.Point(205, 90);
            this.user_name.Name = "user_name";
            this.user_name.Size = new System.Drawing.Size(65, 14);
            this.user_name.TabIndex = 64;
            this.user_name.Text = "اسم العامل";
            // 
            // Home
            // 
            this.Home.BackgroundImage = global::Restraurant_P_1.Properties.Resources._34;
            this.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.Location = new System.Drawing.Point(11, 10);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(33, 32);
            this.Home.TabIndex = 63;
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click_1);
            // 
            // Refresh
            // 
            this.Refresh.BackgroundImage = global::Restraurant_P_1.Properties.Resources._30;
            this.Refresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Refresh.Location = new System.Drawing.Point(50, 12);
            this.Refresh.Name = "Refresh";
            this.Refresh.Size = new System.Drawing.Size(34, 30);
            this.Refresh.TabIndex = 85;
            this.Refresh.UseVisualStyleBackColor = true;
            this.Refresh.Click += new System.EventHandler(this.Refresh_Click);
            // 
            // StuffInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._391;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1027, 350);
            this.Controls.Add(this.Refresh);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.StuffSalary);
            this.Controls.Add(this.StuffAdd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.UserGrid);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.StuffEmail);
            this.Controls.Add(this.StuffPhoneNum);
            this.Controls.Add(this.email);
            this.Controls.Add(this.UserPhone);
            this.Controls.Add(this.StuffCategory);
            this.Controls.Add(this.StuffName);
            this.Controls.Add(this.password);
            this.Controls.Add(this.user_name);
            this.Controls.Add(this.Home);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1043, 389);
            this.MinimumSize = new System.Drawing.Size(1043, 389);
            this.Name = "StuffInfo";
            this.Text = "Stuff";
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox StuffSalary;
        private System.Windows.Forms.TextBox StuffAdd;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridView UserGrid;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox StuffEmail;
        private System.Windows.Forms.TextBox StuffPhoneNum;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label UserPhone;
        private System.Windows.Forms.TextBox StuffCategory;
        private System.Windows.Forms.TextBox StuffName;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Label user_name;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Button Refresh;
    }
}