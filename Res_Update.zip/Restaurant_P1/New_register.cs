﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Restraurant_P_1.DB;

namespace Restraurant_P_1
{
    public partial class New_register : Form
    {
        RestaurantEntities db = new RestaurantEnteties();
        
        public New_register()
        {
            InitializeComponent();
        }

        private void log_in_Click(object sender, EventArgs e)
        {
            var CheckAlreadyExist = db.Users.Where(y => y.UserName == UserName.Text && y.UserPassword == UserPW.Text );
            if (UserName.Text != "" &&
                        UserPW.Text != "" &&
                        UserPhoneNum.Text != "" &&
                        UserEmail.Text != "")
            {
                if (CheckAlreadyExist.Count() > 0)
                {
                    MessageBox.Show("This user already exists !");
                }
                else
                {
                    DialogResult dialogResult = MessageBox.Show("User Name: " + UserName.Text + "\n" + "Password: " + UserPW.Text + "\n" + "Phone: " + UserPhoneNum.Text + "\n" + "Email: " + UserEmail.Text, "Are you sure you want to save ?", MessageBoxButtons.YesNo);
                    if (dialogResult == DialogResult.Yes)
                    {
                        MessageBox.Show("Signed Successfully");
                        db.Users.Add(new User
                        {
                            UserName = UserName.Text,
                            UserPassword = UserPW.Text,
                            UserPhone = int.Parse(UserPhoneNum.Text),
                            UserEmail = UserEmail.Text
                        }
                            );
                        db.SaveChanges();
                        this.Close();
                        Thread th = new Thread(OpenNewForm);
                        th.SetApartmentState(ApartmentState.STA);
                        th.Start();

                    }
                    else if (dialogResult == DialogResult.No)
                    {

                    }

                }
            } else { MessageBox.Show("Please Complete Data !"); }
        }

        private void OpenNewForm()
        {
            Application.Run(new MainForm());
        }

        private void Home_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm2);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm2()
        {
            Application.Run(new MainForm());
        }
    }
    } 
     
      
    
