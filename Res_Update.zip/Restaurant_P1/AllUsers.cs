﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class AllUsers : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();

        public AllUsers()
        {
            InitializeComponent();
            UserGrid.DataSource = db.Users.ToList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Users.Where(x => x.UserName.Contains(UserSearchField.Text)).ToList();
        }

        private void AllUsers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'restaurantDataSet.Users' table. You can move, or remove it, as needed.
            this.usersTableAdapter.Fill(this.restaurantDataSet.Users);

        }

        private void UserGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Users.ToList();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Users.Where(x => x.UserName.Contains(UserSearchField.Text)).ToList();
        }

        private void Home_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new MainForm());
        }

        private void Edit_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm2);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm2()
        {
            Application.Run(new EditUser());
        }

        private void UserSearchField_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }
    

