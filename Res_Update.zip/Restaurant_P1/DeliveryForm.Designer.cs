﻿
namespace Restraurant_P_1
{
    partial class DeliveryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.DeliveryGrid = new System.Windows.Forms.DataGridView();
            this.orderNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deliveryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet12 = new Restraurant_P_1.RestaurantDataSet12();
            this.deliveryTableAdapter = new Restraurant_P_1.RestaurantDataSet12TableAdapters.DeliveryTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DeliveryGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deliveryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet12)).BeginInit();
            this.SuspendLayout();
            // 
            // DeliveryGrid
            // 
            this.DeliveryGrid.AutoGenerateColumns = false;
            this.DeliveryGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DeliveryGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderNameDataGridViewTextBoxColumn,
            this.orderDateDataGridViewTextBoxColumn});
            this.DeliveryGrid.DataSource = this.deliveryBindingSource;
            this.DeliveryGrid.Location = new System.Drawing.Point(222, 60);
            this.DeliveryGrid.Name = "DeliveryGrid";
            this.DeliveryGrid.Size = new System.Drawing.Size(244, 215);
            this.DeliveryGrid.TabIndex = 1;
            // 
            // orderNameDataGridViewTextBoxColumn
            // 
            this.orderNameDataGridViewTextBoxColumn.DataPropertyName = "OrderName";
            this.orderNameDataGridViewTextBoxColumn.HeaderText = "OrderName";
            this.orderNameDataGridViewTextBoxColumn.Name = "orderNameDataGridViewTextBoxColumn";
            // 
            // orderDateDataGridViewTextBoxColumn
            // 
            this.orderDateDataGridViewTextBoxColumn.DataPropertyName = "OrderDate";
            this.orderDateDataGridViewTextBoxColumn.HeaderText = "OrderDate";
            this.orderDateDataGridViewTextBoxColumn.Name = "orderDateDataGridViewTextBoxColumn";
            // 
            // deliveryBindingSource
            // 
            this.deliveryBindingSource.DataMember = "Delivery";
            this.deliveryBindingSource.DataSource = this.restaurantDataSet12;
            // 
            // restaurantDataSet12
            // 
            this.restaurantDataSet12.DataSetName = "RestaurantDataSet12";
            this.restaurantDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // deliveryTableAdapter
            // 
            this.deliveryTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Restraurant_P_1.Properties.Resources._461;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(286, 19);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 35);
            this.button1.TabIndex = 100;
            this.button1.Text = "الدليفري";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // DeliveryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._61;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(479, 287);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.DeliveryGrid);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(495, 326);
            this.MinimumSize = new System.Drawing.Size(495, 326);
            this.Name = "DeliveryForm";
            this.Text = "DeliveryForm";
            this.Load += new System.EventHandler(this.DeliveryForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DeliveryGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deliveryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet12)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView DeliveryGrid;
        private RestaurantDataSet12 restaurantDataSet12;
        private System.Windows.Forms.BindingSource deliveryBindingSource;
        private RestaurantDataSet12TableAdapters.DeliveryTableAdapter deliveryTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button1;
    }
}