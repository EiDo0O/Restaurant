﻿
namespace Restraurant_P_1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip2 = new System.Windows.Forms.MenuStrip();
            this.خياراتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تسجيلالدخولToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إغلاقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المستخدمينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضجميعالمستخدمينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إضافةمستخدمجديدToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.تعديلالمستخدمينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.العملاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضجميعالعملاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إضافةعميلجديدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعديلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعديلمستخدمToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعديلعاملينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعديلطعامToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تعديلعملاءToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الفواتيرToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تقاريرToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.كتابةتقريرجديدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chefs = new System.Windows.Forms.Label();
            this.Food = new System.Windows.Forms.Label();
            this.user_name = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Registeration = new System.Windows.Forms.Button();
            this.menuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip2
            // 
            this.menuStrip2.BackgroundImage = global::Restraurant_P_1.Properties.Resources._221;
            this.menuStrip2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.خياراتToolStripMenuItem,
            this.المستخدمينToolStripMenuItem,
            this.العملاءToolStripMenuItem,
            this.تعديلToolStripMenuItem,
            this.الفواتيرToolStripMenuItem,
            this.تقاريرToolStripMenuItem});
            this.menuStrip2.Location = new System.Drawing.Point(0, 0);
            this.menuStrip2.Name = "menuStrip2";
            this.menuStrip2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.menuStrip2.Size = new System.Drawing.Size(700, 24);
            this.menuStrip2.TabIndex = 18;
            this.menuStrip2.Text = "menuStrip2";
            // 
            // خياراتToolStripMenuItem
            // 
            this.خياراتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تسجيلالدخولToolStripMenuItem,
            this.إغلاقToolStripMenuItem});
            this.خياراتToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources._522233;
            this.خياراتToolStripMenuItem.Name = "خياراتToolStripMenuItem";
            this.خياراتToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.خياراتToolStripMenuItem.Text = "خيارات";
            // 
            // تسجيلالدخولToolStripMenuItem
            // 
            this.تسجيلالدخولToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources.download101;
            this.تسجيلالدخولToolStripMenuItem.Name = "تسجيلالدخولToolStripMenuItem";
            this.تسجيلالدخولToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.تسجيلالدخولToolStripMenuItem.Text = "تسجيل الدخول";
            this.تسجيلالدخولToolStripMenuItem.Click += new System.EventHandler(this.تسجيلالدخولToolStripMenuItem_Click);
            // 
            // إغلاقToolStripMenuItem
            // 
            this.إغلاقToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources.download8;
            this.إغلاقToolStripMenuItem.Name = "إغلاقToolStripMenuItem";
            this.إغلاقToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.إغلاقToolStripMenuItem.Text = "إغلاق";
            this.إغلاقToolStripMenuItem.Click += new System.EventHandler(this.إغلاقToolStripMenuItem_Click);
            // 
            // المستخدمينToolStripMenuItem
            // 
            this.المستخدمينToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.عرضجميعالمستخدمينToolStripMenuItem,
            this.إضافةمستخدمجديدToolStripMenuItem1,
            this.تعديلالمستخدمينToolStripMenuItem});
            this.المستخدمينToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources.download51;
            this.المستخدمينToolStripMenuItem.Name = "المستخدمينToolStripMenuItem";
            this.المستخدمينToolStripMenuItem.Size = new System.Drawing.Size(95, 20);
            this.المستخدمينToolStripMenuItem.Text = "المستخدمين";
            // 
            // عرضجميعالمستخدمينToolStripMenuItem
            // 
            this.عرضجميعالمستخدمينToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources._13;
            this.عرضجميعالمستخدمينToolStripMenuItem.Name = "عرضجميعالمستخدمينToolStripMenuItem";
            this.عرضجميعالمستخدمينToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.عرضجميعالمستخدمينToolStripMenuItem.Text = "عرض جميع المستخدمين";
            this.عرضجميعالمستخدمينToolStripMenuItem.Click += new System.EventHandler(this.عرضجميعالمستخدمينToolStripMenuItem_Click);
            // 
            // إضافةمستخدمجديدToolStripMenuItem1
            // 
            this.إضافةمستخدمجديدToolStripMenuItem1.Image = global::Restraurant_P_1.Properties.Resources.download111;
            this.إضافةمستخدمجديدToolStripMenuItem1.Name = "إضافةمستخدمجديدToolStripMenuItem1";
            this.إضافةمستخدمجديدToolStripMenuItem1.Size = new System.Drawing.Size(192, 22);
            this.إضافةمستخدمجديدToolStripMenuItem1.Text = "إضافة مستخدم جديد";
            this.إضافةمستخدمجديدToolStripMenuItem1.Click += new System.EventHandler(this.إضافةمستخدمجديدToolStripMenuItem1_Click);
            // 
            // تعديلالمستخدمينToolStripMenuItem
            // 
            this.تعديلالمستخدمينToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources.download72;
            this.تعديلالمستخدمينToolStripMenuItem.Name = "تعديلالمستخدمينToolStripMenuItem";
            this.تعديلالمستخدمينToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.تعديلالمستخدمينToolStripMenuItem.Text = "تعديل المستخدمين";
            this.تعديلالمستخدمينToolStripMenuItem.Click += new System.EventHandler(this.تعديلالمستخدمينToolStripMenuItem_Click);
            // 
            // العملاءToolStripMenuItem
            // 
            this.العملاءToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.عرضجميعالعملاءToolStripMenuItem,
            this.إضافةعميلجديدToolStripMenuItem});
            this.العملاءToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources.download3;
            this.العملاءToolStripMenuItem.Name = "العملاءToolStripMenuItem";
            this.العملاءToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.العملاءToolStripMenuItem.Text = "العملاء";
            // 
            // عرضجميعالعملاءToolStripMenuItem
            // 
            this.عرضجميعالعملاءToolStripMenuItem.Name = "عرضجميعالعملاءToolStripMenuItem";
            this.عرضجميعالعملاءToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.عرضجميعالعملاءToolStripMenuItem.Text = "عرض جميع العملاء";
            this.عرضجميعالعملاءToolStripMenuItem.Click += new System.EventHandler(this.عرضجميعالعملاءToolStripMenuItem_Click);
            // 
            // إضافةعميلجديدToolStripMenuItem
            // 
            this.إضافةعميلجديدToolStripMenuItem.Name = "إضافةعميلجديدToolStripMenuItem";
            this.إضافةعميلجديدToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.إضافةعميلجديدToolStripMenuItem.Text = "إضافة عميل جديد";
            this.إضافةعميلجديدToolStripMenuItem.Click += new System.EventHandler(this.إضافةعميلجديدToolStripMenuItem_Click);
            // 
            // تعديلToolStripMenuItem
            // 
            this.تعديلToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.تعديلمستخدمToolStripMenuItem,
            this.تعديلعاملينToolStripMenuItem,
            this.تعديلطعامToolStripMenuItem,
            this.تعديلعملاءToolStripMenuItem});
            this.تعديلToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources.download7;
            this.تعديلToolStripMenuItem.Name = "تعديلToolStripMenuItem";
            this.تعديلToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.تعديلToolStripMenuItem.Text = "تعديل";
            // 
            // تعديلمستخدمToolStripMenuItem
            // 
            this.تعديلمستخدمToolStripMenuItem.Name = "تعديلمستخدمToolStripMenuItem";
            this.تعديلمستخدمToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.تعديلمستخدمToolStripMenuItem.Text = "تعديل مستخدم";
            this.تعديلمستخدمToolStripMenuItem.Click += new System.EventHandler(this.تعديلمستخدمToolStripMenuItem_Click);
            // 
            // تعديلعاملينToolStripMenuItem
            // 
            this.تعديلعاملينToolStripMenuItem.Name = "تعديلعاملينToolStripMenuItem";
            this.تعديلعاملينToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.تعديلعاملينToolStripMenuItem.Text = "تعديل عاملين";
            this.تعديلعاملينToolStripMenuItem.Click += new System.EventHandler(this.تعديلعاملينToolStripMenuItem_Click);
            // 
            // تعديلطعامToolStripMenuItem
            // 
            this.تعديلطعامToolStripMenuItem.Name = "تعديلطعامToolStripMenuItem";
            this.تعديلطعامToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.تعديلطعامToolStripMenuItem.Text = "تعديل طعام";
            this.تعديلطعامToolStripMenuItem.Click += new System.EventHandler(this.تعديلطعامToolStripMenuItem_Click);
            // 
            // تعديلعملاءToolStripMenuItem
            // 
            this.تعديلعملاءToolStripMenuItem.Name = "تعديلعملاءToolStripMenuItem";
            this.تعديلعملاءToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.تعديلعملاءToolStripMenuItem.Text = "تعديل عملاء";
            this.تعديلعملاءToolStripMenuItem.Click += new System.EventHandler(this.تعديلعملاءToolStripMenuItem_Click);
            // 
            // الفواتيرToolStripMenuItem
            // 
            this.الفواتيرToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources.download4;
            this.الفواتيرToolStripMenuItem.Name = "الفواتيرToolStripMenuItem";
            this.الفواتيرToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.الفواتيرToolStripMenuItem.Text = "الفواتير";
            this.الفواتيرToolStripMenuItem.Click += new System.EventHandler(this.الفواتيرToolStripMenuItem_Click);
            // 
            // تقاريرToolStripMenuItem
            // 
            this.تقاريرToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.كتابةتقريرجديدToolStripMenuItem});
            this.تقاريرToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources.download6;
            this.تقاريرToolStripMenuItem.Name = "تقاريرToolStripMenuItem";
            this.تقاريرToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.تقاريرToolStripMenuItem.Text = "تقارير";
            // 
            // كتابةتقريرجديدToolStripMenuItem
            // 
            this.كتابةتقريرجديدToolStripMenuItem.Image = global::Restraurant_P_1.Properties.Resources._361;
            this.كتابةتقريرجديدToolStripMenuItem.Name = "كتابةتقريرجديدToolStripMenuItem";
            this.كتابةتقريرجديدToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.كتابةتقريرجديدToolStripMenuItem.Text = "كتابة تقرير جديد";
            this.كتابةتقريرجديدToolStripMenuItem.Click += new System.EventHandler(this.كتابةتقريرجديدToolStripMenuItem_Click);
            // 
            // chefs
            // 
            this.chefs.AutoSize = true;
            this.chefs.BackColor = System.Drawing.Color.Transparent;
            this.chefs.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chefs.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.chefs.Location = new System.Drawing.Point(112, 177);
            this.chefs.Name = "chefs";
            this.chefs.Size = new System.Drawing.Size(56, 16);
            this.chefs.TabIndex = 24;
            this.chefs.Text = "المبيعات";
            // 
            // Food
            // 
            this.Food.AutoSize = true;
            this.Food.BackColor = System.Drawing.Color.Transparent;
            this.Food.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Food.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Food.Location = new System.Drawing.Point(338, 177);
            this.Food.Name = "Food";
            this.Food.Size = new System.Drawing.Size(49, 16);
            this.Food.TabIndex = 22;
            this.Food.Text = "الطلبات";
            // 
            // user_name
            // 
            this.user_name.AutoSize = true;
            this.user_name.BackColor = System.Drawing.Color.Transparent;
            this.user_name.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_name.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.user_name.Location = new System.Drawing.Point(531, 179);
            this.user_name.Name = "user_name";
            this.user_name.Size = new System.Drawing.Size(78, 16);
            this.user_name.TabIndex = 20;
            this.user_name.Text = "قائمة الطعام";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(114, 330);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 30;
            this.label1.Text = "دليفري";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(340, 329);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 28;
            this.label2.Text = "الخزينة";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(521, 330);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 16);
            this.label3.TabIndex = 26;
            this.label3.Text = "بيانات العاملين";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = global::Restraurant_P_1.Properties.Resources._5;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(76, 201);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(137, 126);
            this.button3.TabIndex = 29;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImage = global::Restraurant_P_1.Properties.Resources._6;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(281, 201);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(147, 123);
            this.button4.TabIndex = 27;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.BackgroundImage = global::Restraurant_P_1.Properties.Resources._1;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(499, 201);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(137, 128);
            this.button5.TabIndex = 25;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = global::Restraurant_P_1.Properties.Resources._3;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(72, 48);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(147, 126);
            this.button2.TabIndex = 23;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::Restraurant_P_1.Properties.Resources._4;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(283, 49);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 127);
            this.button1.TabIndex = 21;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Registeration
            // 
            this.Registeration.BackColor = System.Drawing.Color.Transparent;
            this.Registeration.BackgroundImage = global::Restraurant_P_1.Properties.Resources._2;
            this.Registeration.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Registeration.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Registeration.FlatAppearance.BorderSize = 0;
            this.Registeration.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Registeration.Location = new System.Drawing.Point(499, 58);
            this.Registeration.Name = "Registeration";
            this.Registeration.Size = new System.Drawing.Size(137, 118);
            this.Registeration.TabIndex = 19;
            this.Registeration.UseVisualStyleBackColor = false;
            this.Registeration.Click += new System.EventHandler(this.Registeration_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._12;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(700, 350);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.chefs);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Food);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.user_name);
            this.Controls.Add(this.Registeration);
            this.Controls.Add(this.menuStrip2);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(716, 389);
            this.MinimumSize = new System.Drawing.Size(716, 389);
            this.Name = "MainForm";
            this.Text = "Home";
            this.menuStrip2.ResumeLayout(false);
            this.menuStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip2;
        private System.Windows.Forms.ToolStripMenuItem خياراتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تسجيلالدخولToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إغلاقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المستخدمينToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرضجميعالمستخدمينToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem العملاءToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعديلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الفواتيرToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تقاريرToolStripMenuItem;
        private System.Windows.Forms.Label chefs;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label Food;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label user_name;
        private System.Windows.Forms.Button Registeration;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ToolStripMenuItem إضافةمستخدمجديدToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem تعديلالمستخدمينToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعديلمستخدمToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem كتابةتقريرجديدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرضجميعالعملاءToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إضافةعميلجديدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعديلعاملينToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعديلطعامToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تعديلعملاءToolStripMenuItem;
    }
}