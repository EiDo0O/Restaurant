﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class RequirmentsForm : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        public RequirmentsForm()
        {
            InitializeComponent();

        }

        private void RequirmentsForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'restaurantDataSet15.Requirments' table. You can move, or remove it, as needed.
            this.requirmentsTableAdapter1.Fill(this.restaurantDataSet15.Requirments);
            // TODO: This line of code loads data into the 'restaurantDataSet13.Requirments' table. You can move, or remove it, as needed.
            this.requirmentsTableAdapter.Fill(this.restaurantDataSet13.Requirments);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
            var Select = db.Requirments.SingleOrDefault(x => x.Id == IdObj);

            Select.State = Full.Text;

            db.SaveChanges();
            UserGrid.DataSource = db.Requirments.ToList();


        }

        private void button4_Click(object sender, EventArgs e)
        {
            int IdObj = int.Parse(UserGrid.CurrentRow.Cells[0].Value.ToString());
            var Select = db.Requirments.SingleOrDefault(x => x.Id == IdObj);

            Select.State = Incomplete.Text;


            db.SaveChanges();
            UserGrid.DataSource = db.Requirments.ToList();

        }

        private void UserGrid_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
           if (e.ColumnIndex == 3 & e.Value != null)
            {
                String St = Convert.ToString(e.Value);
                if (St == Full.Text)
                {
                    e.CellStyle.BackColor = Color.Green;
                } else if (St == Incomplete.Text)
                {
                    e.CellStyle.BackColor = Color.Red;
                }
            }

        }  
        

        private void Home_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new MainForm());
        }

        private void button5_MouseHover(object sender, EventArgs e)
        {
            button5.BackColor = Color.Black;
            button5.ForeColor = Color.White;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Requirments.Where(x => x.State == Incomplete.Text).ToList();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Requirments.ToList();
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {
            button5.BackColor = DefaultBackColor;
            button5.ForeColor = Color.Black;

        }
    }
}
