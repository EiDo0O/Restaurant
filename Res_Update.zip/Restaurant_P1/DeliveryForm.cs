﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class DeliveryForm : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        public DeliveryForm()
        {
            InitializeComponent();
            
        }

        private void DeliveryForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'restaurantDataSet12.Delivery' table. You can move, or remove it, as needed.
            this.deliveryTableAdapter.Fill(this.restaurantDataSet12.Delivery);

        }
    }
    
}
