﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
     
    public partial class AddFood : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        public AddFood()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Added Successfully");
            db.Foods.Add(new Restraurant_P_1.DB.Food
            {
               FoodName = FoodName.Text ,
            FoodQuantity = int.Parse(FoodQuantity.Text),
           FoodPrice = float.Parse(FoodPrice.Text),
           FoodCategory = CategoryCombo.Text,
            CategoryId = int.Parse(CategoryCombo.SelectedValue.ToString())
        }
               );
            db.SaveChanges();
            this.Close();
        }
    }
}
