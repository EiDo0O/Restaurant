﻿
namespace Restraurant_P_1
{
    partial class RequirmentsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.UserGrid = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.requirmentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityRequiredDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.requirmentsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet15 = new Restraurant_P_1.RestaurantDataSet15();
            this.requirmentsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet13 = new Restraurant_P_1.RestaurantDataSet13();
            this.requirmentsTableAdapter = new Restraurant_P_1.RestaurantDataSet13TableAdapters.RequirmentsTableAdapter();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.Full = new System.Windows.Forms.Label();
            this.Incomplete = new System.Windows.Forms.Label();
            this.requirmentsTableAdapter1 = new Restraurant_P_1.RestaurantDataSet15TableAdapters.RequirmentsTableAdapter();
            this.Home = new System.Windows.Forms.Button();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDocument2 = new System.Drawing.Printing.PrintDocument();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.requirmentsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.requirmentsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet13)).BeginInit();
            this.SuspendLayout();
            // 
            // UserGrid
            // 
            this.UserGrid.AutoGenerateColumns = false;
            this.UserGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UserGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.requirmentNameDataGridViewTextBoxColumn,
            this.quantityRequiredDataGridViewTextBoxColumn,
            this.stateDataGridViewTextBoxColumn});
            this.UserGrid.DataSource = this.requirmentsBindingSource1;
            this.UserGrid.Location = new System.Drawing.Point(173, 50);
            this.UserGrid.Name = "UserGrid";
            this.UserGrid.Size = new System.Drawing.Size(342, 253);
            this.UserGrid.TabIndex = 2;
            this.UserGrid.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.UserGrid_CellFormatting);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Width = 30;
            // 
            // requirmentNameDataGridViewTextBoxColumn
            // 
            this.requirmentNameDataGridViewTextBoxColumn.DataPropertyName = "RequirmentName";
            this.requirmentNameDataGridViewTextBoxColumn.HeaderText = "RequirmentName";
            this.requirmentNameDataGridViewTextBoxColumn.Name = "requirmentNameDataGridViewTextBoxColumn";
            // 
            // quantityRequiredDataGridViewTextBoxColumn
            // 
            this.quantityRequiredDataGridViewTextBoxColumn.DataPropertyName = "QuantityRequired";
            this.quantityRequiredDataGridViewTextBoxColumn.HeaderText = "QuantityRequired";
            this.quantityRequiredDataGridViewTextBoxColumn.Name = "quantityRequiredDataGridViewTextBoxColumn";
            // 
            // stateDataGridViewTextBoxColumn
            // 
            this.stateDataGridViewTextBoxColumn.DataPropertyName = "State";
            this.stateDataGridViewTextBoxColumn.HeaderText = "State";
            this.stateDataGridViewTextBoxColumn.Name = "stateDataGridViewTextBoxColumn";
            this.stateDataGridViewTextBoxColumn.Width = 80;
            // 
            // requirmentsBindingSource1
            // 
            this.requirmentsBindingSource1.DataMember = "Requirments";
            this.requirmentsBindingSource1.DataSource = this.restaurantDataSet15;
            // 
            // restaurantDataSet15
            // 
            this.restaurantDataSet15.DataSetName = "RestaurantDataSet15";
            this.restaurantDataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // requirmentsBindingSource
            // 
            this.requirmentsBindingSource.DataMember = "Requirments";
            this.requirmentsBindingSource.DataSource = this.restaurantDataSet13;
            // 
            // restaurantDataSet13
            // 
            this.restaurantDataSet13.DataSetName = "RestaurantDataSet13";
            this.restaurantDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // requirmentsTableAdapter
            // 
            this.requirmentsTableAdapter.ClearBeforeFill = true;
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Restraurant_P_1.Properties.Resources._642;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button1.Location = new System.Drawing.Point(289, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 35);
            this.button1.TabIndex = 101;
            this.button1.Text = "الطلبات";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackgroundImage = global::Restraurant_P_1.Properties.Resources._65;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(32, 119);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(117, 35);
            this.button2.TabIndex = 102;
            this.button2.Text = "الحالـة";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::Restraurant_P_1.Properties.Resources._63;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button3.Location = new System.Drawing.Point(97, 169);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(41, 35);
            this.button3.TabIndex = 103;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackgroundImage = global::Restraurant_P_1.Properties.Resources._64;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button4.Location = new System.Drawing.Point(41, 169);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(41, 35);
            this.button4.TabIndex = 104;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Full
            // 
            this.Full.AutoSize = true;
            this.Full.BackColor = System.Drawing.Color.Transparent;
            this.Full.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Full.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Full.Location = new System.Drawing.Point(100, 207);
            this.Full.Name = "Full";
            this.Full.Size = new System.Drawing.Size(34, 16);
            this.Full.TabIndex = 105;
            this.Full.Text = "كامل";
            // 
            // Incomplete
            // 
            this.Incomplete.AutoSize = true;
            this.Incomplete.BackColor = System.Drawing.Color.Transparent;
            this.Incomplete.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Incomplete.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Incomplete.Location = new System.Drawing.Point(42, 207);
            this.Incomplete.Name = "Incomplete";
            this.Incomplete.Size = new System.Drawing.Size(38, 16);
            this.Incomplete.TabIndex = 106;
            this.Incomplete.Text = "ناقص";
            // 
            // requirmentsTableAdapter1
            // 
            this.requirmentsTableAdapter1.ClearBeforeFill = true;
            // 
            // Home
            // 
            this.Home.BackgroundImage = global::Restraurant_P_1.Properties.Resources._34;
            this.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.Location = new System.Drawing.Point(8, 7);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(33, 32);
            this.Home.TabIndex = 107;
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(47, 11);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(103, 24);
            this.button5.TabIndex = 108;
            this.button5.Text = "عرض جميع النواقص";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            this.button5.MouseLeave += new System.EventHandler(this.button5_MouseLeave);
            this.button5.MouseHover += new System.EventHandler(this.button5_MouseHover);
            // 
            // button6
            // 
            this.button6.BackgroundImage = global::Restraurant_P_1.Properties.Resources._66;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Location = new System.Drawing.Point(181, 21);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(30, 27);
            this.button6.TabIndex = 109;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // RequirmentsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._62;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(610, 315);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.Home);
            this.Controls.Add(this.Incomplete);
            this.Controls.Add(this.Full);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.UserGrid);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(626, 354);
            this.MinimumSize = new System.Drawing.Size(626, 354);
            this.Name = "RequirmentsForm";
            this.Text = "RequirmentsForm";
            this.Load += new System.EventHandler(this.RequirmentsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.requirmentsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.requirmentsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet13)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView UserGrid;
        private RestaurantDataSet13 restaurantDataSet13;
        private System.Windows.Forms.BindingSource requirmentsBindingSource;
        private RestaurantDataSet13TableAdapters.RequirmentsTableAdapter requirmentsTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label Full;
        private System.Windows.Forms.Label Incomplete;
        private RestaurantDataSet15 restaurantDataSet15;
        private System.Windows.Forms.BindingSource requirmentsBindingSource1;
        private RestaurantDataSet15TableAdapters.RequirmentsTableAdapter requirmentsTableAdapter1;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn requirmentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityRequiredDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stateDataGridViewTextBoxColumn;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Drawing.Printing.PrintDocument printDocument2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
    }
}