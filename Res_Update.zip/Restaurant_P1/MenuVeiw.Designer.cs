﻿
namespace Restraurant_P_1
{
    partial class MenuVeiw
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.FoodSearchField = new System.Windows.Forms.TextBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.UserGrid = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodQuantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodCategoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.foodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet8 = new Restraurant_P_1.RestaurantDataSet8();
            this.label1 = new System.Windows.Forms.Label();
            this.Refresh = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Home = new System.Windows.Forms.Button();
            this.foodTableAdapter = new Restraurant_P_1.RestaurantDataSet8TableAdapters.FoodTableAdapter();
            this.CategoryCombo = new System.Windows.Forms.ComboBox();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.restaurantDataSet9 = new Restraurant_P_1.RestaurantDataSet9();
            this.categoryTableAdapter = new Restraurant_P_1.RestaurantDataSet9TableAdapters.CategoryTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet9)).BeginInit();
            this.SuspendLayout();
            // 
            // FoodSearchField
            // 
            this.FoodSearchField.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FoodSearchField.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.FoodSearchField.Location = new System.Drawing.Point(84, 11);
            this.FoodSearchField.Multiline = true;
            this.FoodSearchField.Name = "FoodSearchField";
            this.FoodSearchField.Size = new System.Drawing.Size(134, 24);
            this.FoodSearchField.TabIndex = 133;
            this.FoodSearchField.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // SearchButton
            // 
            this.SearchButton.BackColor = System.Drawing.Color.Transparent;
            this.SearchButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SearchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SearchButton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.SearchButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SearchButton.Location = new System.Drawing.Point(219, 11);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(53, 24);
            this.SearchButton.TabIndex = 132;
            this.SearchButton.Text = "بحث";
            this.SearchButton.UseVisualStyleBackColor = false;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // UserGrid
            // 
            this.UserGrid.AutoGenerateColumns = false;
            this.UserGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UserGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.foodNameDataGridViewTextBoxColumn,
            this.foodQuantityDataGridViewTextBoxColumn,
            this.foodCategoryDataGridViewTextBoxColumn,
            this.foodPriceDataGridViewTextBoxColumn});
            this.UserGrid.DataSource = this.foodBindingSource;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.UserGrid.DefaultCellStyle = dataGridViewCellStyle1;
            this.UserGrid.Location = new System.Drawing.Point(87, 40);
            this.UserGrid.Name = "UserGrid";
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.UserGrid.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.UserGrid.Size = new System.Drawing.Size(506, 304);
            this.UserGrid.TabIndex = 122;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // foodNameDataGridViewTextBoxColumn
            // 
            this.foodNameDataGridViewTextBoxColumn.DataPropertyName = "FoodName";
            this.foodNameDataGridViewTextBoxColumn.HeaderText = "FoodName";
            this.foodNameDataGridViewTextBoxColumn.Name = "foodNameDataGridViewTextBoxColumn";
            // 
            // foodQuantityDataGridViewTextBoxColumn
            // 
            this.foodQuantityDataGridViewTextBoxColumn.DataPropertyName = "FoodQuantity";
            this.foodQuantityDataGridViewTextBoxColumn.HeaderText = "FoodQuantity";
            this.foodQuantityDataGridViewTextBoxColumn.Name = "foodQuantityDataGridViewTextBoxColumn";
            // 
            // foodCategoryDataGridViewTextBoxColumn
            // 
            this.foodCategoryDataGridViewTextBoxColumn.DataPropertyName = "FoodCategory";
            this.foodCategoryDataGridViewTextBoxColumn.HeaderText = "FoodCategory";
            this.foodCategoryDataGridViewTextBoxColumn.Name = "foodCategoryDataGridViewTextBoxColumn";
            // 
            // foodPriceDataGridViewTextBoxColumn
            // 
            this.foodPriceDataGridViewTextBoxColumn.DataPropertyName = "FoodPrice";
            this.foodPriceDataGridViewTextBoxColumn.HeaderText = "FoodPrice";
            this.foodPriceDataGridViewTextBoxColumn.Name = "foodPriceDataGridViewTextBoxColumn";
            // 
            // foodBindingSource
            // 
            this.foodBindingSource.DataMember = "Food";
            this.foodBindingSource.DataSource = this.restaurantDataSet8;
            // 
            // restaurantDataSet8
            // 
            this.restaurantDataSet8.DataSetName = "RestaurantDataSet8";
            this.restaurantDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(443, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 27);
            this.label1.TabIndex = 120;
            this.label1.Text = "قائمة الطعام";
            // 
            // Refresh
            // 
            this.Refresh.BackgroundImage = global::Restraurant_P_1.Properties.Resources._30;
            this.Refresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Refresh.Location = new System.Drawing.Point(43, 7);
            this.Refresh.Name = "Refresh";
            this.Refresh.Size = new System.Drawing.Size(34, 30);
            this.Refresh.TabIndex = 130;
            this.Refresh.UseVisualStyleBackColor = true;
            this.Refresh.Click += new System.EventHandler(this.Refresh_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImage = global::Restraurant_P_1.Properties.Resources.imag1;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button3.Location = new System.Drawing.Point(555, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 32);
            this.button3.TabIndex = 121;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Home
            // 
            this.Home.BackgroundImage = global::Restraurant_P_1.Properties.Resources._591;
            this.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.Location = new System.Drawing.Point(5, 7);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(32, 30);
            this.Home.TabIndex = 112;
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // foodTableAdapter
            // 
            this.foodTableAdapter.ClearBeforeFill = true;
            // 
            // CategoryCombo
            // 
            this.CategoryCombo.DataSource = this.categoryBindingSource;
            this.CategoryCombo.DisplayMember = "Category";
            this.CategoryCombo.FormattingEnabled = true;
            this.CategoryCombo.Location = new System.Drawing.Point(296, 13);
            this.CategoryCombo.Name = "CategoryCombo";
            this.CategoryCombo.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.CategoryCombo.Size = new System.Drawing.Size(121, 21);
            this.CategoryCombo.TabIndex = 134;
            this.CategoryCombo.ValueMember = "Id";
            this.CategoryCombo.SelectedIndexChanged += new System.EventHandler(this.CategoryCombo_SelectedIndexChanged);
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.restaurantDataSet9;
            // 
            // restaurantDataSet9
            // 
            this.restaurantDataSet9.DataSetName = "RestaurantDataSet9";
            this.restaurantDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // MenuVeiw
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._81;
            this.ClientSize = new System.Drawing.Size(600, 350);
            this.Controls.Add(this.CategoryCombo);
            this.Controls.Add(this.FoodSearchField);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.Refresh);
            this.Controls.Add(this.UserGrid);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Home);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(616, 389);
            this.MinimumSize = new System.Drawing.Size(616, 389);
            this.Name = "MenuVeiw";
            this.Text = "MenuVeiw";
            this.Load += new System.EventHandler(this.MenuVeiw_Load);
            ((System.ComponentModel.ISupportInitialize)(this.UserGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.foodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.restaurantDataSet9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox FoodSearchField;
        private System.Windows.Forms.Button SearchButton;
        private System.Windows.Forms.Button Refresh;
        private System.Windows.Forms.DataGridView UserGrid;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Home;
        private RestaurantDataSet8 restaurantDataSet8;
        private System.Windows.Forms.BindingSource foodBindingSource;
        private RestaurantDataSet8TableAdapters.FoodTableAdapter foodTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodQuantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodCategoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn foodPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.ComboBox CategoryCombo;
        private RestaurantDataSet9 restaurantDataSet9;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private RestaurantDataSet9TableAdapters.CategoryTableAdapter categoryTableAdapter;
    }
}