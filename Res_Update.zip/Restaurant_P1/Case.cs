﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class Case : Form
    {
        public Case()
        {
            InitializeComponent();
        }

        private void CaseOpen_Click(object sender, EventArgs e)
        {
            CasePass cp = new CasePass();
            cp.Show();
        }

        private void Home_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new MainForm());
        }
    }
}
