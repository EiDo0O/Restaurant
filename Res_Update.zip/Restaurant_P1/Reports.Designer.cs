﻿
namespace Restraurant_P_1
{
    partial class Reports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReportField = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Print = new System.Windows.Forms.Button();
            this.Refresh = new System.Windows.Forms.Button();
            this.Home = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ReportField
            // 
            this.ReportField.Location = new System.Drawing.Point(182, 48);
            this.ReportField.Multiline = true;
            this.ReportField.Name = "ReportField";
            this.ReportField.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.ReportField.Size = new System.Drawing.Size(413, 267);
            this.ReportField.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(446, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 27);
            this.label1.TabIndex = 98;
            this.label1.Text = "كتابة تقرير جديد";
            // 
            // Print
            // 
            this.Print.BackgroundImage = global::Restraurant_P_1.Properties.Resources._48;
            this.Print.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Print.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Print.Location = new System.Drawing.Point(45, 244);
            this.Print.Name = "Print";
            this.Print.Size = new System.Drawing.Size(102, 43);
            this.Print.TabIndex = 99;
            this.Print.Text = "طباعة";
            this.Print.UseVisualStyleBackColor = true;
            this.Print.Click += new System.EventHandler(this.Print_Click);
            // 
            // Refresh
            // 
            this.Refresh.BackgroundImage = global::Restraurant_P_1.Properties.Resources._30;
            this.Refresh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Refresh.Location = new System.Drawing.Point(46, 6);
            this.Refresh.Name = "Refresh";
            this.Refresh.Size = new System.Drawing.Size(34, 30);
            this.Refresh.TabIndex = 110;
            this.Refresh.UseVisualStyleBackColor = true;
            this.Refresh.Click += new System.EventHandler(this.Refresh_Click);
            // 
            // Home
            // 
            this.Home.BackgroundImage = global::Restraurant_P_1.Properties.Resources._34;
            this.Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Home.Location = new System.Drawing.Point(7, 5);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(33, 32);
            this.Home.TabIndex = 109;
            this.Home.UseVisualStyleBackColor = true;
            this.Home.Click += new System.EventHandler(this.Home_Click);
            // 
            // Reports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Restraurant_P_1.Properties.Resources._47;
            this.ClientSize = new System.Drawing.Size(600, 320);
            this.Controls.Add(this.Refresh);
            this.Controls.Add(this.Home);
            this.Controls.Add(this.Print);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ReportField);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(616, 359);
            this.MinimumSize = new System.Drawing.Size(616, 359);
            this.Name = "Reports";
            this.Text = "Reports";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ReportField;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Print;
        private System.Windows.Forms.Button Refresh;
        private System.Windows.Forms.Button Home;
    }
}