﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Restraurant_P_1
{
    public partial class MenuVeiw : Form
    {
        RestaurantEnteties db = new RestaurantEnteties();
        public MenuVeiw()
        {
            InitializeComponent();
        }

        private void Home_Click(object sender, EventArgs e)
        {
            this.Close();
            Thread th = new Thread(OpenNewForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        void OpenNewForm()
        {
            Application.Run(new Interface());
        }

        private void MenuVeiw_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'restaurantDataSet9.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this.restaurantDataSet9.Category);
            // TODO: This line of code loads data into the 'restaurantDataSet8.Food' table. You can move, or remove it, as needed.
            this.foodTableAdapter.Fill(this.restaurantDataSet8.Food);

        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Foods.Where(x => x.FoodName.Contains(FoodSearchField.Text)).ToList();

        }

        private void Refresh_Click(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Foods.ToList();

        }

        private void CategoryCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            UserGrid.DataSource = db.Foods.Where(x => x.FoodCategory == CategoryCombo.Text).ToList();

        }
    }
}
