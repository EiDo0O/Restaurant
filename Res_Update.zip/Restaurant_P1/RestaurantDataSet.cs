﻿namespace Restraurant_P_1
{


    partial class RestaurantDataSet
    {
    }
}
